use serenity::async_trait;
use serenity::model::gateway::Ready;
use serenity::model::channel::Message;
use serenity::model::id::UserId;
use serenity::prelude::*;
use serenity::builder::{CreateAttachment, CreateMessage, CreateEmbed, CreateEmbedFooter};
use serenity::gateway::ActivityData;
use std::env;
use std::fs;
use std::sync::Arc;
use std::collections::HashMap;
use std::time::{Duration, Instant};
use tokio::sync::Mutex;
use crate::obfuscator::NothingProtectionV5;

// ── Rate limiter: max 3 requests per user per minute ────────────────────────
const RATE_LIMIT_MAX: usize = 3;
const RATE_LIMIT_WINDOW: Duration = Duration::from_secs(60);
const MAX_FILE_SIZE: usize = 2 * 1024 * 1024; // 2MB max file size
const MAX_OUTPUT_SIZE: usize = 50 * 1024 * 1024; // 50MB max output
const OBF_TIMEOUT: Duration = Duration::from_secs(120); // 2 minute timeout

type RateLimitMap = Arc<Mutex<HashMap<UserId, Vec<Instant>>>>;

struct BotState {
    rate_limits: RateLimitMap,
    total_obfuscations: Mutex<u64>,
    start_time: Instant,
}

impl BotState {
    fn new() -> Self {
        Self {
            rate_limits: Arc::new(Mutex::new(HashMap::new())),
            total_obfuscations: Mutex::new(0),
            start_time: Instant::now(),
        }
    }
}

struct Handler {
    state: Arc<BotState>,
}

#[async_trait]
impl EventHandler for Handler {
    async fn message(&self, ctx: Context, msg: Message) {
        if msg.author.bot { return; }

        let content_trimmed = msg.content.trim().to_lowercase();
        let is_obf = content_trimmed.starts_with("!obf");
        let is_help = content_trimmed == "!help";
        let is_ping = content_trimmed == "!ping";
        let is_status = content_trimmed == "!status";
        let is_stats = content_trimmed == "!stats";

        if !is_obf && !is_help && !is_ping && !is_status && !is_stats {
            return;
        }

        // ── Rate limiting ───────────────────────────────────────────────────
        if is_obf {
            let can_proceed = check_rate_limit(&self.state.rate_limits, msg.author.id).await;
            if !can_proceed {
                let _ = msg.channel_id.send_message(&ctx.http,
                    CreateMessage::new().content(
                        format!("⏳ <@{}> Rate limit: max `{}` obfuscations per `{}` seconds. Please wait.",
                            msg.author.id, RATE_LIMIT_MAX, RATE_LIMIT_WINDOW.as_secs())
                    )
                ).await;
                return;
            }
        }

        // ── !obf command ────────────────────────────────────────────────────
        if is_obf {
            handle_obf(ctx, msg, Arc::clone(&self.state)).await;
            return;
        }

        // ── !help command ───────────────────────────────────────────────────
        if is_help {
            let embed = CreateEmbed::new()
                .title("Nothing Protection v5 — Lua/LuaU Obfuscator")
                .description(
                    "**Usage:** `!obf [level] [layers]` with an attached `.lua` / `.luau` file\n\n\
                    **Levels:**\n\
                    \u{2022} `basic [1-10]` \u2014 lightweight XOR + base64 encryption\n\
                    \u{2022} `high [1-10]` \u2014 multi-pass XOR encryption\n\
                    \u{2022} `vm [1-10]` \u2014 real Lua bytecode VM (randomized opcode table)\n\
                    \u{2022} `maximum [1-10]` *(default)* \u2014 up to 3 stacked VMs + CFG\n\n\
                    **How layers work (maximum):**\n\
                    ```\n\
                    VM Layer 1 \u2014 bytecode VM, randomized opcodes + register map\n\
                    VM Layer 2 \u2014 second VM wrapping Layer 1 (layers \u2265 6)\n\
                    VM Layer 3 \u2014 triple VM stack (layers \u2265 9)\n\
                    Enc 1..N   \u2014 XOR-encrypt shells, unique random key each\n\
                    Outer      \u2014 table-index API resolution, no rawget/string literals\n\
                    ```\n\
                    Everything (guards, junk, watermarks) is **inside the innermost VM layer** \u2014 \
                    nothing is readable in the output file.\n\n\
                    **Protection features (inside the encrypted blob):**\n\
                    \u{2022} Exploit API detection (100+ executor globals checked)\n\
                    \u{2022} Roblox environment validation (game, workspace, RunService)\n\
                    \u{2022} Anti-decompiler traps (bit rotation, upvalue probes, hash checks)\n\
                    \u{2022} 24+ randomized junk functions with opaque predicates\n\
                    \u{2022} PRNG xorshift-32 string encryption, hex/binary register indices\n\
                    \u{2022} Bytecode checksum + build watermark verification\n\
                    \u{2022} Control-flow graph obfuscation on outer decoder\n\
                    \u{2022} Custom symbol names (@$#^&* etc.) for visual obfuscation\n\n\
                    **Other commands:** `!ping` `!status` `!stats`"
                )
                .color(0x2F3136)
                .footer(CreateEmbedFooter::new("Nothing Protection v5 | Bot"));
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().add_embed(embed)
            ).await;
            return;
        }

        // ── !ping command ───────────────────────────────────────────────────
        if is_ping {
            let uptime = self.state.start_time.elapsed();
            let uptime_str = format_duration(uptime);
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().content(
                    format!("\u{1F3D3} Pong! NPv5 is online. Uptime: `{}`", uptime_str)
                )
            ).await;
            return;
        }

        // ── !status command ─────────────────────────────────────────────────
        if is_status {
            let count = *self.state.total_obfuscations.lock().await;
            let uptime = self.state.start_time.elapsed();
            let embed = CreateEmbed::new()
                .title("NPv5 Bot Status")
                .field("Status", "\u{2705} Online", true)
                .field("Uptime", format_duration(uptime), true)
                .field("Obfuscations", count.to_string(), true)
                .field("Rate Limit", format!("{} req / {} sec", RATE_LIMIT_MAX, RATE_LIMIT_WINDOW.as_secs()), true)
                .field("Max File Size", fmt_size(MAX_FILE_SIZE), true)
                .field("VM Layers", "Up to 3 stacked", true)
                .color(0x00AA00)
                .footer(CreateEmbedFooter::new("Nothing Protection v5"));
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().add_embed(embed)
            ).await;
            return;
        }

        // ── !stats command ──────────────────────────────────────────────────
        if is_stats {
            let count = *self.state.total_obfuscations.lock().await;
            let uptime = self.state.start_time.elapsed();
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().content(
                    format!(
                        "\u{1F4CA} **Bot Stats**\n\
                        Total obfuscations: `{}`\n\
                        Uptime: `{}`\n\
                        Rate limit: `{}` req / `{}` sec per user",
                        count, format_duration(uptime), RATE_LIMIT_MAX, RATE_LIMIT_WINDOW.as_secs()
                    )
                )
            ).await;
            return;
        }
    }

    async fn ready(&self, ctx: Context, ready: Ready) {
        println!("[NPv5] {} is online! (ID: {})", ready.user.name, ready.user.id);
        ctx.set_activity(Some(ActivityData::watching("!obf maximum 10")));
    }
}

// ── Obfuscation handler ─────────────────────────────────────────────────────
async fn handle_obf(ctx: Context, msg: Message, state: Arc<BotState>) {
    let parts: Vec<&str> = msg.content.split_whitespace().collect();

    let level = parts.get(1).copied().unwrap_or("maximum").to_lowercase();
    let layers: usize = parts.get(2)
        .and_then(|s| s.parse::<usize>().ok())
        .map(|n| n.clamp(1, 10))
        .unwrap_or_else(|| match level.as_str() {
            "basic"   => 1,
            "high"    => 3,
            "vm"      => 4,
            _         => 10,
        });

    let valid_level = matches!(level.as_str(), "basic" | "high" | "vm" | "maximum");

    if let Some(attachment) = msg.attachments.first() {
        // File size check
        if let Some(size) = attachment.size {
            if size as usize > MAX_FILE_SIZE {
                let _ = msg.channel_id.send_message(&ctx.http,
                    CreateMessage::new().content(
                        format!("\u{274C} File too large (`{}`). Max size: `{}`.",
                            fmt_size(size as usize), fmt_size(MAX_FILE_SIZE))
                    )
                ).await;
                return;
            }
        }

        let fname = attachment.filename.to_lowercase();
        let supported = fname.ends_with(".lua")
            || fname.ends_with(".luau")
            || fname.ends_with(".luac")
            || fname.ends_with(".txt");

        if !supported {
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().content(
                    "\u{274C} Unsupported file type. Supported: `.lua` \u00B7 `.luau` \u00B7 `.luac` \u00B7 `.txt`"
                )
            ).await;
            return;
        }

        if !valid_level {
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().content(
                    "\u{274C} Unknown level. Use: `basic` \u00B7 `high` \u00B7 `vm` \u00B7 `maximum`"
                )
            ).await;
            return;
        }

        let progress_msg = match msg.channel_id.send_message(&ctx.http,
            CreateMessage::new().content(
                format!("\u{23F3} Obfuscating with **{}** level, **{}** layers\u2026", level, layers)
            )
        ).await {
            Ok(m) => Some(m),
            Err(_) => None,
        };

        let content = match attachment.download().await {
            Ok(bytes) => String::from_utf8_lossy(&bytes).to_string(),
            Err(e) => {
                let _ = msg.channel_id.send_message(&ctx.http,
                    CreateMessage::new().content(format!("\u{274C} Failed to download attachment: {:?}", e))
                ).await;
                return;
            }
        };

        let content_owned = content.clone();
        let level_owned = level.clone();

        // Run obfuscation with timeout
        let obf_result = tokio::time::timeout(OBF_TIMEOUT, tokio::task::spawn_blocking(move || {
            std::panic::catch_unwind(move || {
                let mut obf = NothingProtectionV5::new(&level_owned, None, None);
                let result = obf.obfuscate(&content_owned, layers);
                let vm_cnt = obf.vm_count;
                (result, vm_cnt)
            })
        })).await;

        let (result, vm_count) = match obf_result {
            Ok(Ok(Ok(pair))) => pair,
            Ok(Ok(Err(_))) => {
                let _ = msg.channel_id.send_message(&ctx.http,
                    CreateMessage::new().content(
                        "\u{274C} Obfuscation panicked \u2014 the script may contain syntax this engine can't handle. \
                         Try `!obf high` or `!obf basic` for simpler protection."
                    )
                ).await;
                return;
            }
            Ok(Err(_)) => {
                let _ = msg.channel_id.send_message(&ctx.http,
                    CreateMessage::new().content("\u{274C} Obfuscation task failed to spawn.")
                ).await;
                return;
            }
            Err(_) => {
                let _ = msg.channel_id.send_message(&ctx.http,
                    CreateMessage::new().content(
                        format!("\u{274C} Obfuscation timed out (>{} sec). Try a smaller script or fewer layers.",
                            OBF_TIMEOUT.as_secs())
                    )
                ).await;
                return;
            }
        };

        // Output size check
        if result.len() > MAX_OUTPUT_SIZE {
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().content(
                    format!("\u{274C} Output too large (`{}`). Max: `{}`. Try fewer layers.",
                        fmt_size(result.len()), fmt_size(MAX_OUTPUT_SIZE))
                )
            ).await;
            return;
        }

        // Update stats
        {
            let mut count = state.total_obfuscations.lock().await;
            *count += 1;
        }

        let orig_len = content.len();
        let result_len = result.len();
        let ratio = result_len as f64 / orig_len.max(1) as f64;

        let out_name = format!("protected_{}", attachment.filename.replace(' ', "_"));
        let out_path = format!("/tmp/{}", out_name);

        if fs::write(&out_path, result.as_bytes()).is_err() {
            let _ = msg.channel_id.send_message(&ctx.http,
                CreateMessage::new().content("\u{274C} Failed to write output file.")
            ).await;
            return;
        }

        let level_label = match level.as_str() {
            "basic"   => "Basic (1\u00D7 XOR encrypt)",
            "high"    => "High (multi-pass XOR encrypt)",
            "vm"      => "VM (bytecode VM + encryption)",
            _         => "Maximum (up to 3\u00D7 VM + multi-layer encryption + CFG)",
        };

        let vm_info = if vm_count > 0 {
            format!(" \u00B7 VMs: `{}`", vm_count)
        } else {
            String::new()
        };

        let cfg_count = if level == "maximum" { layers / 2 } else { 0 };
        let layer_detail = match level.as_str() {
            "maximum" => format!(
                "**Protection breakdown:**\n\
                 \u{2022} Source scramble: `1 pass` (junk lines between real code)\n\
                 \u{2022} Bytecode VM: `up to 3 layers` (custom register-VM, randomised opcodes)\n\
                 \u{2022} XOR-b64 encryption: `{enc}` shells (unique random key each)\n\
                 \u{2022} CFG noise: `{cfg}` layers (goto/while dispatch on alternating shells)\n\
                 \u{2022} Anti-exploit: `49` executor API checks\n\
                 \u{2022} Roblox guards: `6` environment assertions\n\
                 \u{2022} Anti-decompiler: `9` runtime traps\n\
                 \u{2022} Junk code: `24` dead functions\n\
                 \u{2022} Custom symbols: `@$#^&*` mixed in variable names\n\
                 \u{2022} Build watermark: runtime hash verification\n\
                 > Total shells to peel: **{total}** ({enc} decrypt + {vm_count} VM reverse)",
                enc = layers - 1,
                cfg = cfg_count,
                total = layers,
                vm_count = vm_count,
            ),
            "vm" => format!(
                "**Protection breakdown:**\n\
                 \u{2022} Bytecode VM: `up to 3 layers`\n\
                 \u{2022} XOR-b64 encryption: `{enc}` shells",
                enc = layers - 1,
            ),
            "high" => format!(
                "**Protection breakdown:**\n\
                 \u{2022} XOR-b64 encryption: `{enc}` shells",
                enc = layers,
            ),
            _ => format!(
                "**Protection breakdown:**\n\
                 \u{2022} XOR-b64 encryption: `1` shell",
            ),
        };

        let summary = format!(
            "\u{2705} **Protected!**\n\
             Level: `{}` \u00B7 Layers: `{}`{}\n\
             Size: `{}` \u2192 `{}` (`{:.1}\u00D7`)\n\
             {}\n\
             > Outer shell: **no** `loadstring`/`pcall`/`bit32` strings visible \u2014 all API names recovered at runtime via char-codes.",
            level_label, layers, vm_info,
            fmt_size(orig_len), fmt_size(result_len), ratio,
            layer_detail,
        );

        let ca = match CreateAttachment::path(&out_path).await {
            Ok(a) => a,
            Err(_) => {
                let _ = msg.channel_id.send_message(&ctx.http,
                    CreateMessage::new().content("\u{274C} Failed to prepare output file.")
                ).await;
                let _ = fs::remove_file(&out_path);
                return;
            }
        };

        let builder = CreateMessage::new().content(summary).add_file(ca);
        let _ = msg.channel_id.send_message(&ctx.http, builder).await;
        let _ = fs::remove_file(&out_path);

        // Delete progress message if it exists
        if let Some(pm) = progress_msg {
            let _ = pm.delete(&ctx.http).await;
        }

    } else {
        // No attachment \u2014 print usage
        let usage = format!(
            "\u{1F4CE} **Attach a `.lua` / `.luau` file** and use one of:\n\n\
            `!obf basic [layers]`   \u2014 XOR encryption (fast, 1 layer default)\n\
            `!obf high [layers]`    \u2014 Multi-pass XOR (3 layers default)\n\
            `!obf vm [layers]`      \u2014 Bytecode VM + encryption (4 layers default, up to 3 VMs)\n\
            `!obf maximum [layers]` \u2014 3\u00D7VM + multi-layer + CFG (**10 layers default**, max 10)\n\n\
            **Examples:**\n\
            `!obf maximum` \u2014 10-layer max protection (3 stacked VMs at layer 9+)\n\
            `!obf maximum 8` \u2014 8-layer protection (2 stacked VMs)\n\
            `!obf vm 8` \u2014 VM with 3 stacked VMs + 5 encryption layers\n\n\
            > For maximum: up to 3 stacked bytecode VMs (random opcode+register map) + N XOR shells\n\
            > Guards, junk code, watermarks, and **custom symbols** are hidden **inside** the innermost layer."
        );
        let _ = msg.channel_id.send_message(&ctx.http,
            CreateMessage::new().content(usage)
        ).await;
    }
}

// ── Rate limit check ────────────────────────────────────────────────────────
async fn check_rate_limit(limits: &RateLimitMap, user_id: UserId) -> bool {
    let mut map = limits.lock().await;
    let now = Instant::now();
    let entries = map.entry(user_id).or_default();
    // Remove old entries outside the window
    entries.retain(|&t| now.duration_since(t) < RATE_LIMIT_WINDOW);
    if entries.len() >= RATE_LIMIT_MAX {
        return false;
    }
    entries.push(now);
    true
}

// ── Duration formatter ──────────────────────────────────────────────────────
fn format_duration(d: Duration) -> String {
    let secs = d.as_secs();
    let mins = secs / 60;
    let hours = mins / 60;
    let days = hours / 24;
    if days > 0 {
        format!("{}d {}h {}m {}s", days, hours % 24, mins % 60, secs % 60)
    } else if hours > 0 {
        format!("{}h {}m {}s", hours, mins % 60, secs % 60)
    } else if mins > 0 {
        format!("{}m {}s", mins, secs % 60)
    } else {
        format!("{}s", secs)
    }
}

// ── Size formatter ──────────────────────────────────────────────────────────
fn fmt_size(bytes: usize) -> String {
    if bytes < 1024 { format!("{}B", bytes) }
    else if bytes < 1024 * 1024 { format!("{:.1}KB", bytes as f64 / 1024.0) }
    else { format!("{:.1}MB", bytes as f64 / 1024.0 / 1024.0) }
}

// ── Bot entrypoint ──────────────────────────────────────────────────────────
pub async fn run_bot() {
    let token = env::var("DISCORD_BOT_TOKEN")
        .expect("DISCORD_BOT_TOKEN env var not set");
    let intents = GatewayIntents::GUILD_MESSAGES
        | GatewayIntents::DIRECT_MESSAGES
        | GatewayIntents::MESSAGE_CONTENT;

    let state = Arc::new(BotState::new());

    let mut client = Client::builder(&token, intents)
        .event_handler(Handler { state })
        .await
        .expect("Error creating client");

    if let Err(e) = client.start().await {
        println!("[NPv5] Client error: {:?}", e);
    }
}
