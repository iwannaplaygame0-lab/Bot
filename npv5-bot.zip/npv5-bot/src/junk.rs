use rand::Rng;

pub struct JunkGenerator {
    rng: rand::rngs::ThreadRng,
}

impl JunkGenerator {
    pub fn new() -> Self { Self { rng: rand::thread_rng() } }

    // Format a number as a random Luau literal: hex / binary-with-underscores / decimal
    fn numlit(&mut self, n: u64) -> String {
        match self.rng.gen_range(0u8..8) {
            0 => format!("0x{:X}", n),
            1 => format!("0X{:x}", n),
            2 => {
                let v = (n & 0xFFFF) as u32;
                if v == 0 { return "0".to_string(); }
                let bits = format!("{:b}", v);
                if bits.len() > 5 {
                    let mid = bits.len() - 4;
                    format!("0B{}__{}", &bits[..mid], &bits[mid..])
                } else { format!("0B{}", bits) }
            }
            3 => {
                let v = (n & 0xFFFF) as u32;
                if v == 0 { return "0".to_string(); }
                let bits = format!("{:b}", v);
                if bits.len() > 5 {
                    let mid = bits.len() - 4;
                    format!("0b{}_{}", &bits[..mid], &bits[mid..])
                } else { format!("0b{}", bits) }
            }
            4 => format!("0x{:04X}", n & 0xFFFF),
            5 => {
                let v = n & 0xFF;
                format!("0B{:04b}_{:04b}", (v >> 4) & 0xF, v & 0xF)
            }
            6 => {
                let v = n & 0xFF;
                format!("0B{:08b}", v)
            }
            _ => format!("{}", n),
        }
    }

    // Always-true opaque predicates
    fn opaque_true(&mut self) -> String {
        let n: u32 = self.rng.gen_range(2..255);
        let nf = self.numlit(n as u64);
        let nf2 = self.numlit(n as u64);
        match self.rng.gen_range(0u8..7) {
            0 => format!("(bit32.band({nf},{nf2})=={nf})"),
            1 => {
                let m: u32 = self.rng.gen_range(1..100);
                let mf = self.numlit(m as u64);
                format!("(({nf}+{mf}-{mf})=={nf2})")
            }
            2 => format!("(bit32.bor(0,{nf})=={nf2})"),
            3 => format!("(type(tostring)==\"function\")"),
            4 => {
                let k: u32 = self.rng.gen_range(1..31);
                let kf = self.numlit(k as u64);
                format!("(bit32.lrotate(bit32.rrotate({nf},{kf}),{kf})=={nf2})")
            }
            5 => format!("(bit32.bxor({nf},0)=={nf2})"),
            _ => {
                let v = n as u64 * 2;
                let vf = self.numlit(v);
                format!("(bit32.rshift({vf},1)=={nf})")
            }
        }
    }

    // Always-false opaque predicates
    fn opaque_false(&mut self) -> String {
        let n: u32 = self.rng.gen_range(1..255);
        let nf = self.numlit(n as u64);
        let nf2 = self.numlit(n as u64);
        match self.rng.gen_range(0u8..5) {
            0 => format!("(bit32.bxor({nf},{nf2})~=0)"),
            1 => format!("(bit32.band({nf},0)~=0)"),
            2 => format!("({nf}~={nf2}+1)"),
            3 => format!("(type(nil)==\"number\")"),
            _ => format!("({nf}+1=={nf2})"),
        }
    }

    fn gen_name(&mut self) -> String {
        let chars: Vec<char> = "Il1l0OQq_oO@$#!?~^&*+=|:;.< >%".chars().collect();
        let len = self.rng.gen_range(10..18usize);
        let mut name = String::from("_");
        for _ in 0..len {
            name.push(chars[self.rng.gen_range(0..chars.len())]);
        }
        name
    }

    fn rand_hex(&mut self, len: usize) -> String {
        (0..len).map(|_| format!("{:x}", self.rng.gen::<u8>())).collect()
    }

    // Generate a single dead/junk code block
    fn dead_block(&mut self) -> String {
        let v1 = self.gen_name(); let v2 = self.gen_name();
        let a: u32 = self.rng.gen_range(1..200);
        let b: u32 = self.rng.gen_range(1..50);
        let af = self.numlit(a as u64);
        let bf = self.numlit(b as u64);
        match self.rng.gen_range(0u8..8) {
            0 => format!(
                "      local {v1}={af}\n      for _i=1,{bf} do {v1}=bit32.bxor({v1},_i) end\n      {v1}=nil"),
            1 => {
                let hex = self.rand_hex(8);
                format!("      local {v1}=\"{hex}\"\n      local {v2}=string.len({v1})\n      {v2}=nil")
            }
            2 => format!(
                "      local {v1}={{}}\n      for _i=1,{bf} do {v1}[_i]=_i*{af} end\n      {v1}=nil"),
            3 => format!(
                "      local {v1}=0\n      local {v2}=function() return {af} end\n      {v1}={v2}()*0\n      {v1}=nil;{v2}=nil"),
            4 => format!(
                "      local {v1}=string.rep(\"x\",{bf})\n      {v1}=string.gsub({v1},\"x\",\"\")\n      {v1}=nil"),
            5 => format!(
                "      local {v1}=bit32.bxor({af},{bf})\n      {v1}=bit32.band({v1},{})\n      {v1}=nil",
                self.numlit(0xFFFFFFFF)),
            6 => {
                let c = self.rng.gen_range(2..30u32);
                let cf = self.numlit(c as u64);
                format!("      local {v1}={af}\n      {v1}=math.floor({v1}/{cf})*{cf}\n      {v1}=nil")
            }
            _ => {
                let c: u32 = self.rng.gen_range(1..0xFFFF);
                let cf = self.numlit(c as u64);
                format!("      local {v1}={}; local {v2}={cf}\n      if {v1}+{v2}>0 then {v1}=0 end\n      {v1}=nil",
                    self.numlit(0))
            }
        }
    }

    // Generate N junk functions and return them as a Lua chunk
    // Named gen_library for compatibility with obfuscator.rs call site
    pub fn gen_library(&mut self, count: usize) -> String {
        let mut s = String::new();
        for _ in 0..count {
            let variant = self.rng.gen_range(0usize..14);
            s += &self.gen_junk_function(variant);
            s += "\n";
        }
        s
    }

    fn gen_junk_function(&mut self, variant: usize) -> String {
        let fname = self.gen_name();
        let v1 = self.gen_name(); let v2 = self.gen_name();
        let v3 = self.gen_name(); let v4 = self.gen_name();
        let a: u32 = self.rng.gen_range(1..999);
        let b: u32 = self.rng.gen_range(1..999);
        let c: u32 = self.rng.gen_range(1..0xFFFF);
        let af = self.numlit(a as u64);
        let bf = self.numlit(b as u64);
        let cf = self.numlit(c as u64);
        let n = self.rng.gen_range(1..50u32);
        let nf = self.numlit(n as u64);
        let op_true  = self.opaque_true();
        let op_false = self.opaque_false();
        let dead1 = self.dead_block();
        let dead2 = self.dead_block();

        match variant {
            0 => format!(
r#"local {fname}=(function()
  local {v1}={af}; local {v2}={bf}
  for {v3}=1,{nf} do
    {v1}=bit32.bxor({v1},{v3})
    if {op_false} then
{dead1}
    end
  end
  if {op_true} then
    {v2}=bit32.band({v1},{cf})
  end
  return {v2}
end)()"#),
            1 => format!(
r#"local {fname}=(function()
  local {v1}={}
  local {v2}={{}}
  for {v3}=1,{nf} do
    {v2}[{v3}]=bit32.bxor({v3},{cf})
    if {op_false} then
{dead1}
    end
  end
  {v1}=#{v2}
  return {v1}
end)()"#, self.numlit(0)),
            2 => {
                let hex = self.rand_hex(12);
                format!(
r#"local {fname}=(function()
  local {v1}="{hex}"
  local {v2}=0
  for {v3}=1,#({v1}) do
    {v2}=bit32.bxor({v2},string.byte({v1},{v3}))
  end
  if {op_false} then
{dead1}
  end
  return {v2}
end)()"#)
            }
            3 => format!(
r#"local {fname}=(function()
  local {v1}={af}; local {v2}={bf}
  local {v3}=function()
    if {op_true} then
      return bit32.band({v1}+{v2},{cf})
    end
    return 0
  end
  local {v4}={v3}()
  return {v4}
end)()"#),
            4 => {
                let k: u32 = self.rng.gen_range(1..31);
                let kf = self.numlit(k as u64);
                format!(
r#"local {fname}=(function()
  local {v1}={cf}
  local {v2}=bit32.lrotate({v1},{kf})
  local {v3}=bit32.rrotate({v2},{kf})
  if {v3}~={v1} then repeat until false end
  if {op_false} then
{dead1}
  end
  return {v3}
end)()"#)
            }
            5 => format!(
r#"local {fname}=(function()
  local {v1}={}
  for {v3}=1,{nf} do
    {v1}={v1}+bit32.band({v3},{cf})
    if bit32.bxor({af},{bf})==bit32.bxor({af},{bf}) then
      {v1}=bit32.band({v1},{})
    end
  end
  return {v1}
end)()"#, self.numlit(0), self.numlit(0xFFFFFFFF)),
            6 => {
                let s1 = self.rng.gen_range(10..99u32);
                let s2 = self.rng.gen_range(100..199u32);
                let s1f = self.numlit(s1 as u64);
                let s2f = self.numlit(s2 as u64);
                let sw = self.gen_name(); let pc = self.gen_name();
                format!(
r#"local {fname}=(function()
  local {pc}={s1f}
  local {sw}
  {sw}=function()
    if {pc}=={s1f} then
      if {op_false} then
{dead1}
      end
      {pc}={s2f}
      return {sw}()
    elseif {pc}=={s2f} then
      if {op_true} then
        {pc}={s1f}+{s2f}
      end
    end
    return 0
  end
  return {sw}()
end)()"#)
            }
            7 => {
                let lbl1 = format!("_lbl_{:08x}", self.rng.gen::<u32>());
                let lbl2 = format!("_lbl_{:08x}", self.rng.gen::<u32>());
                format!(
r#"local {fname}=(function()
  local {v1}=bit32.bxor({af},{bf})
  ::{lbl1}::
  if {op_false} then
{dead1}
    goto {lbl2}
  end
  if {op_true} then
    {v1}=bit32.band({v1},{cf})
  end
  ::{lbl2}::
  return {v1}
end)()"#)
            }
            8 => format!(
r#"local {fname}=(function()
  local {v1}={af}; local {v2}={}
  local {v3}=function({v4})
    return bit32.band({v4}*{v1},{cf})
  end
  for _i=1,{nf} do
    {v2}={v3}(_i)
    if {op_false} then
{dead1}
    end
  end
  return {v2}
end)()"#, self.numlit(0)),
            9 => {
                let str_len = self.rng.gen_range(4..12u32);
                let sf = self.numlit(str_len as u64);
                format!(
r#"local {fname}=(function()
  local {v1}=string.rep("x",{sf})
  local {v2}=0
  if #{v1}~={sf} then repeat until false end
  if {op_true} then
    {v2}=bit32.band(string.len({v1}),{cf})
  end
  if {op_false} then
{dead1}
  end
  return {v2}
end)()"#)
            }
            10 => format!(
r#"local {fname}=(function()
  local {v1}={}
  local {v2}={{}}
  for {v3}=1,{nf} do
    if bit32.band({v3},1)==0 then
      {v2}[#{v2}+1]=bit32.bxor({v3},{cf})
    end
  end
  {v1}=#{v2}
  if {op_false} then
{dead2}
  end
  return {v1}
end)()"#, self.numlit(0)),
            11 => {
                let m: u32 = self.rng.gen_range(2..16);
                let mf = self.numlit(m as u64);
                format!(
r#"local {fname}=(function()
  local {v1}={af}; local {v2}={}
  for {v3}=0,{nf} do
    if {v3}%{mf}==0 then
      {v2}=bit32.bxor({v2},{v3}+{v1})
    end
  end
  if {op_true} then
    {v2}=bit32.band({v2},{cf})
  end
  return {v2}
end)()"#, self.numlit(0))
            }
            12 => {
                let magic: u32 = self.rng.gen_range(0x1000..0xFFFF);
                let magf = self.numlit(magic as u64);
                let magf2 = self.numlit(magic as u64);
                format!(
r#"local {fname}=(function()
  local {v1}={magf}
  local {v2}=function() return {v1} end
  if {v2}()~={magf2} then repeat until false end
  if {op_false} then
{dead1}
  end
  return {v2}()
end)()"#)
            }
            _ => {
                // variant 13: nested CFG with goto+while dispatch
                let sw = self.gen_name(); let pc = self.gen_name();
                let fs = self.rng.gen_range(200..299u32);
                let fsf = self.numlit(fs as u64);
                let ms = self.rng.gen_range(50..99u32);
                let msf = self.numlit(ms as u64);
                let es = self.rng.gen_range(1..20u32);
                let esf = self.numlit(es as u64);
                format!(
r#"local {fname}=(function()
  local {pc}={esf}
  local {sw}
  {sw}=function()
    while {pc}~={fsf} do
      if {pc}=={msf} then
        {pc}={fsf}
        if {op_true} then
          return bit32.band({af}+{bf},{cf})
        end
      elseif {pc}=={esf} then
        if {op_false} then
{dead1}
        end
        {pc}={msf}
        return {sw}()
      else
        {pc}={fsf}
      end
    end
    return 0
  end
  return {sw}()
end)()"#)
            }
        }
    }
}
