mod tokenizer;
mod ast;
mod parser;
mod encrypt;
mod bytecode;
mod vm;
mod obfuscator;
mod cfg;
mod watermark;
mod junk;
mod bot;

use std::env;
use std::fs;
use obfuscator::NothingProtectionV5;

#[tokio::main]
async fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() > 1 && args[1] == "bot" {
        bot::run_bot().await;
        return;
    }

    if args.len() < 2 || args[1] == "--help" || args[1] == "-h" {
        println!("Nothing Protection v5.1 — Lua/LuaU Obfuscator");
        println!();
        println!("USAGE:");
        println!("  {} bot                              Run Discord bot", args[0]);
        println!("  {} <input.lua> <output.lua>         Obfuscate a file", args[0]);
        println!("  {} --watermark                      Show the watermark", args[0]);
        println!();
        println!("OPTIONS:");
        println!("  --level <basic|high|vm|maximum>   Protection level (default: maximum)");
        println!("  --layers <1-10>                   Number of obfuscation layers (default: 10)");
        println!("  --seed <u64>                      Random seed for reproducible output");
        println!("  --preserve <name1,name2,...>      Preserve these variable names");
        println!();
        println!("LEVELS:");
        println!("  basic    — 1\u00d7 XOR + base64 encryption");
        println!("  high     — Multi-pass XOR encryption");
        println!("  vm       — Real Lua bytecode VM + encryption (up to 3 stacked VMs)");
        println!("  maximum  — Up to 3 stacked VMs + multi-layer encryption + CFG");
        println!();
        println!("EXAMPLES:");
        println!("  {} myscript.lua out.lua --level maximum --layers 10", args[0]);
        println!("  {} myscript.lua out.lua --level vm --layers 8", args[0]);
        println!("  {} myscript.lua out.lua --level basic", args[0]);
        std::process::exit(0);
    }

    if args[1] == "--watermark" {
        println!("{}", NothingProtectionV5::watermark());
        std::process::exit(0);
    }

    if args.len() < 3 {
        eprintln!("Usage: {} <input.lua> <output.lua> [--level <level>] [--layers <n>] [--seed <n>]");
        eprintln!("       {} bot  -- Run Discord bot", args[0]);
        eprintln!("       {} --help  -- Show full help", args[0]);
        std::process::exit(1);
    }

    let input  = &args[1];
    let output = &args[2];
    let mut level = "maximum";
    let mut seed: Option<u64> = None;
    let mut preserve: Option<Vec<String>> = None;
    let mut layers: usize = 10;   // default 10 for maximum mode

    let mut i = 3;
    while i < args.len() {
        match args[i].as_str() {
            "--level"    => { i += 1; if i < args.len() { level = &args[i]; } }
            "--seed"     => { i += 1; if i < args.len() { seed = args[i].parse().ok(); } }
            "--layers"   => { i += 1; if i < args.len() { layers = args[i].parse().unwrap_or(10).clamp(1, 10); } }
            "--preserve" => { i += 1; if i < args.len() { preserve = Some(args[i].split(',').map(|s| s.to_string()).collect()); } }
            _ => {}
        }
        i += 1;
    }

    let code = fs::read_to_string(input).expect("Failed to read input");
    let mut obf = NothingProtectionV5::new(level, seed, preserve);
    let result = obf.obfuscate(&code, layers);
    fs::write(output, result).expect("Failed to write output");
    println!("[NPv5] Done. Output: {}", output);
}
