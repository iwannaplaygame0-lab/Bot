use crate::ast::ASTNode;
use std::collections::HashMap;

pub const MAX_REGISTERS: usize = 2000;
pub const OPCODE_COUNT: usize = 33;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum OpCode {
    LoadK = 0,
    Move = 1,
    Add = 2,
    Sub = 3,
    Mul = 4,
    Div = 5,
    Mod = 6,
    Pow = 7,
    Unm = 8,
    Not = 9,
    Len = 10,
    Concat = 11,
    Eq = 12,
    Lt = 13,
    Le = 14,
    Ne = 15,
    Jmp = 16,
    LoadBool = 17,
    LoadNil = 18,
    NewTable = 19,
    GetTable = 20,
    SetTable = 21,
    Call = 22,
    Return = 23,
    Closure = 24,
    GetUpval = 25,
    SetUpval = 26,
    Band = 27,
    Bor = 28,
    Bxor = 29,
    ToNum = 30,
    ToStr = 31,
    TestJmp = 32,
}

impl OpCode {
    pub fn to_u8(self) -> u8 { self as u8 }
    pub fn from_u8(v: u8) -> Option<Self> {
        if v < OPCODE_COUNT as u8 { Some(unsafe { std::mem::transmute(v) }) } else { None }
    }
}

#[derive(Debug, Clone)]
pub struct Instruction {
    pub op: u8,
    pub a: u16,
    pub b: u16,
    pub c: u16,
}

impl Instruction {
    pub fn new(op: u8, a: u16, b: u16, c: u16) -> Self {
        Self { op, a, b, c }
    }
    pub fn to_bytes(&self) -> [u8; 8] {
        let mut out = [0u8; 8];
        out[0] = self.op;
        out[2..4].copy_from_slice(&self.a.to_le_bytes());
        out[4..6].copy_from_slice(&self.b.to_le_bytes());
        out[6..8].copy_from_slice(&self.c.to_le_bytes());
        out
    }
    pub fn from_bytes(bytes: [u8; 8]) -> Self {
        Self {
            op: bytes[0],
            a: u16::from_le_bytes([bytes[2], bytes[3]]),
            b: u16::from_le_bytes([bytes[4], bytes[5]]),
            c: u16::from_le_bytes([bytes[6], bytes[7]]),
        }
    }
}

#[derive(Debug, Clone)]
pub struct Constant {
    pub value: String,
    pub ctype: String,
}

#[derive(Debug, Clone, Copy)]
pub enum UpvalSource {
    ParentLocal(usize),
    ParentUpval(usize),
}

#[derive(Debug, Clone)]
pub struct BytecodeFunction {
    pub instructions: Vec<Instruction>,
    pub constants: Vec<Constant>,
    pub locals: Vec<String>,
    pub params: usize,
    pub registers_used: usize,
    pub protos: Vec<BytecodeFunction>,
    pub upvalues: Vec<UpvalSource>,
    pub upvalue_names: Vec<String>,
}

#[derive(Clone, Default)]
struct ParentBindings {
    locals: HashMap<String, usize>,
    upvalue_names: Vec<String>,
}

pub struct BytecodeCompiler {
    func: BytecodeFunction,
    free_reg: usize,
    local_map: HashMap<String, usize>,
    upval_map: HashMap<String, usize>,
    const_map: HashMap<String, usize>,
    parent: ParentBindings,
}

impl BytecodeCompiler {
    pub fn new(params: Vec<String>) -> Self {
        Self::with_parent(params, ParentBindings::default())
    }

    fn with_parent(params: Vec<String>, parent: ParentBindings) -> Self {
        let mut local_map = HashMap::new();
        let mut free_reg = 0;
        for (i, p) in params.iter().enumerate() {
            local_map.insert(p.clone(), i);
            free_reg = i + 1;
        }
        Self {
            func: BytecodeFunction {
                instructions: Vec::new(),
                constants: Vec::new(),
                locals: params.clone(),
                params: params.len(),
                registers_used: free_reg,
                protos: Vec::new(),
                upvalues: Vec::new(),
                upvalue_names: Vec::new(),
            },
            free_reg,
            local_map,
            upval_map: HashMap::new(),
            const_map: HashMap::new(),
            parent,
        }
    }

    pub fn compile_function(&mut self, chunk: &ASTNode) -> BytecodeFunction {
        self.compile_block(chunk);
        self.emit(OpCode::LoadNil as u8, 0, 0, 0);
        self.emit(OpCode::Return as u8, 0, 1, 0);
        self.func.registers_used = self.func.registers_used.max(self.free_reg);
        self.func.clone()
    }

    fn compile_block(&mut self, chunk: &ASTNode) {
        if let ASTNode::Chunk(stats) = chunk {
            for stat in stats {
                self.compile_stat(stat);
            }
        }
    }

    fn alloc_reg(&mut self) -> usize {
        let r = self.free_reg;
        self.free_reg += 1;
        if self.free_reg > self.func.registers_used {
            self.func.registers_used = self.free_reg;
        }
        r
    }

    fn emit(&mut self, op: u8, a: u16, b: u16, c: u16) {
        self.func.instructions.push(Instruction::new(op, a, b, c));
    }

    fn add_const(&mut self, val: &str, ctype: &str) -> usize {
        let key = format!("{}:{}", ctype, val);
        if let Some(&idx) = self.const_map.get(&key) {
            return idx;
        }
        let idx = self.func.constants.len();
        self.func.constants.push(Constant { value: val.to_string(), ctype: ctype.to_string() });
        self.const_map.insert(key, idx);
        idx
    }

    fn resolve_local(&self, name: &str) -> Option<usize> {
        self.local_map.get(name).copied()
    }

    fn resolve_upval(&mut self, name: &str) -> Option<usize> {
        if let Some(&idx) = self.upval_map.get(name) {
            return Some(idx);
        }
        if let Some(&preg) = self.parent.locals.get(name) {
            let idx = self.func.upvalues.len();
            self.func.upvalues.push(UpvalSource::ParentLocal(preg));
            self.func.upvalue_names.push(name.to_string());
            self.upval_map.insert(name.to_string(), idx);
            return Some(idx);
        }
        if let Some(pos) = self.parent.upvalue_names.iter().position(|n| n == name) {
            let idx = self.func.upvalues.len();
            self.func.upvalues.push(UpvalSource::ParentUpval(pos));
            self.func.upvalue_names.push(name.to_string());
            self.upval_map.insert(name.to_string(), idx);
            return Some(idx);
        }
        None
    }

    fn patch_jump(&mut self, pos: usize, offset: i32) {
        let bits = offset as u32;
        self.func.instructions[pos].b = (bits >> 16) as u16;
        self.func.instructions[pos].c = (bits & 0xFFFF) as u16;
    }

    fn compile_nested_proto(&mut self, params: &[String], body: &ASTNode) -> usize {
        let snapshot = ParentBindings {
            locals: self.local_map.clone(),
            upvalue_names: self.func.upvalue_names.clone(),
        };
        let mut nested = BytecodeCompiler::with_parent(params.to_vec(), snapshot);
        nested.compile_block(body);
        nested.emit(OpCode::LoadNil as u8, 0, 0, 0);
        nested.emit(OpCode::Return as u8, 0, 1, 0);
        nested.func.registers_used = nested.func.registers_used.max(nested.free_reg);
        let idx = self.func.protos.len();
        self.func.protos.push(nested.func);
        idx
    }

    fn compile_stat(&mut self, stat: &ASTNode) {
        match stat {
            ASTNode::LocalDecl(names, vals) => {
                let mut reg_vals = Vec::new();
                for val in vals {
                    reg_vals.push(self.compile_expr(val));
                }
                for (i, name) in names.iter().enumerate() {
                    let r = if i < reg_vals.len() {
                        reg_vals[i]
                    } else {
                        let nr = self.alloc_reg();
                        self.emit(OpCode::LoadNil as u8, nr as u16, 0, 0);
                        nr
                    };
                    self.local_map.insert(name.clone(), r);
                    self.func.locals.push(name.clone());
                }
            }
            ASTNode::AssignStmt(targets, vals) => {
                let mut reg_vals = Vec::new();
                for val in vals {
                    reg_vals.push(self.compile_expr(val));
                }
                for (i, target) in targets.iter().enumerate() {
                    let src = match reg_vals.get(i) { Some(&r) => r, None => continue };
                    match target {
                        ASTNode::Ident(name) => {
                            if let Some(reg) = self.resolve_local(name) {
                                self.emit(OpCode::Move as u8, reg as u16, src as u16, 0);
                            } else if let Some(uidx) = self.resolve_upval(name) {
                                self.emit(OpCode::SetUpval as u8, src as u16, uidx as u16, 0);
                            }
                        }
                        ASTNode::MemberExpr { base, member } => {
                            let b = self.compile_expr(base);
                            let k = self.add_const(member, "string");
                            let kr = self.alloc_reg();
                            self.emit(OpCode::LoadK as u8, kr as u16, (k >> 8) as u16, (k & 0xFF) as u16);
                            self.emit(OpCode::SetTable as u8, b as u16, kr as u16, src as u16);
                        }
                        ASTNode::IndexExpr { base, index } => {
                            let b = self.compile_expr(base);
                            let idx = self.compile_expr(index);
                            self.emit(OpCode::SetTable as u8, b as u16, idx as u16, src as u16);
                        }
                        _ => {}
                    }
                }
            }
            ASTNode::IfStmt { cond, then_body, else_body } => {
                let cond_reg = self.compile_expr(cond);
                let jmp_else = self.func.instructions.len();
                self.emit(OpCode::TestJmp as u8, cond_reg as u16, 0, 0);

                self.compile_block(then_body);
                let jmp_end = self.func.instructions.len();
                self.emit(OpCode::Jmp as u8, 0, 0, 0);

                let else_start = self.func.instructions.len();
                if let Some(e) = else_body {
                    self.compile_block(e);
                }
                let end = self.func.instructions.len();

                self.patch_jump(jmp_else, else_start as i32 - jmp_else as i32);
                self.patch_jump(jmp_end, end as i32 - jmp_end as i32);
            }
            ASTNode::WhileStmt { cond, body } => {
                let loop_start = self.func.instructions.len();
                let cond_reg = self.compile_expr(cond);
                let jmp_out = self.func.instructions.len();
                self.emit(OpCode::TestJmp as u8, cond_reg as u16, 0, 0);

                self.compile_block(body);
                let back_pos = self.func.instructions.len();
                self.emit(OpCode::Jmp as u8, 0, 0, 0);
                self.patch_jump(back_pos, loop_start as i32 - back_pos as i32);

                let out_pos = self.func.instructions.len();
                self.patch_jump(jmp_out, out_pos as i32 - jmp_out as i32);
            }
            ASTNode::RepeatStmt { body, cond } => {
                let loop_start = self.func.instructions.len();
                self.compile_block(body);
                let cond_reg = self.compile_expr(cond);
                let neg = self.alloc_reg();
                self.emit(OpCode::Not as u8, neg as u16, cond_reg as u16, 0);
                let jmp_pos = self.func.instructions.len();
                self.emit(OpCode::TestJmp as u8, neg as u16, 0, 0);
                self.patch_jump(jmp_pos, loop_start as i32 - jmp_pos as i32);
            }
            ASTNode::ForStmt { var, start, end, step, body } => {
                let start_reg = self.compile_expr(start);
                let end_reg = self.compile_expr(end);
                let step_reg = if let Some(s) = step {
                    self.compile_expr(s)
                } else {
                    let r = self.alloc_reg();
                    let k = self.add_const("1", "number");
                    self.emit(OpCode::LoadK as u8, r as u16, (k >> 8) as u16, (k & 0xFF) as u16);
                    r
                };
                let counter = self.alloc_reg();
                self.emit(OpCode::Move as u8, counter as u16, start_reg as u16, 0);
                self.local_map.insert(var.clone(), counter);

                let loop_start = self.func.instructions.len();
                let test_reg = self.alloc_reg();
                self.emit(OpCode::Lt as u8, test_reg as u16, counter as u16, end_reg as u16);
                let jmp_out = self.func.instructions.len();
                self.emit(OpCode::TestJmp as u8, test_reg as u16, 0, 0);

                self.compile_block(body);
                self.emit(OpCode::Add as u8, counter as u16, counter as u16, step_reg as u16);
                let back_pos = self.func.instructions.len();
                self.emit(OpCode::Jmp as u8, 0, 0, 0);
                self.patch_jump(back_pos, loop_start as i32 - back_pos as i32);

                let out_pos = self.func.instructions.len();
                self.patch_jump(jmp_out, out_pos as i32 - jmp_out as i32);
            }
            ASTNode::ReturnStmt(vals) => {
                if vals.is_empty() {
                    self.emit(OpCode::LoadNil as u8, 0, 0, 0);
                    self.emit(OpCode::Return as u8, 0, 1, 0);
                } else {
                    let mut regs = Vec::new();
                    for v in vals {
                        regs.push(self.compile_expr(v));
                    }
                    let base = regs[0];
                    self.emit(OpCode::Return as u8, base as u16, regs.len() as u16, 0);
                }
            }
            ASTNode::FuncDecl { name, params, body, local } => {
                let proto_idx = self.compile_nested_proto(params, body);
                let r = self.alloc_reg();
                self.emit(OpCode::Closure as u8, r as u16, (proto_idx >> 8) as u16, (proto_idx & 0xFF) as u16);
                if *local {
                    self.local_map.insert(name.clone(), r);
                    self.func.locals.push(name.clone());
                } else if let Some(reg) = self.resolve_local(name) {
                    self.emit(OpCode::Move as u8, reg as u16, r as u16, 0);
                } else if let Some(uidx) = self.resolve_upval(name) {
                    self.emit(OpCode::SetUpval as u8, r as u16, uidx as u16, 0);
                } else {
                    self.local_map.insert(name.clone(), r);
                    self.func.locals.push(name.clone());
                }
            }
            ASTNode::FuncExpr { params, body } => {
                let proto_idx = self.compile_nested_proto(params, body);
                let r = self.alloc_reg();
                self.emit(OpCode::Closure as u8, r as u16, (proto_idx >> 8) as u16, (proto_idx & 0xFF) as u16);
            }
            ASTNode::ForInStmt { vars, iters, body } => {
                let mut iter_regs = Vec::new();
                for it in iters {
                    iter_regs.push(self.compile_expr(it));
                }
                for (i, var) in vars.iter().enumerate() {
                    let r = if i < iter_regs.len() { iter_regs[i] } else { self.alloc_reg() };
                    self.local_map.insert(var.clone(), r);
                    self.func.locals.push(var.clone());
                }
                self.compile_block(body);
            }
            ASTNode::DoStmt(body) => {
                self.compile_block(body);
            }
            ASTNode::BreakStmt => {}
            ASTNode::Chunk(stats) => {
                for s in stats {
                    self.compile_stat(s);
                }
            }
            other => {
                self.compile_expr(other);
            }
        }
    }

    fn compile_expr(&mut self, expr: &ASTNode) -> usize {
        match expr {
            ASTNode::Literal { value, ltype } => {
                let r = self.alloc_reg();
                let k = self.add_const(value, ltype);
                self.emit(OpCode::LoadK as u8, r as u16, (k >> 8) as u16, (k & 0xFF) as u16);
                r
            }
            ASTNode::Ident(name) => {
                if let Some(reg) = self.resolve_local(name) {
                    reg
                } else if let Some(uidx) = self.resolve_upval(name) {
                    let r = self.alloc_reg();
                    self.emit(OpCode::GetUpval as u8, r as u16, uidx as u16, 0);
                    r
                } else {
                    let r = self.alloc_reg();
                    let k = self.add_const(name, "global");
                    self.emit(OpCode::LoadK as u8, r as u16, (k >> 8) as u16, (k & 0xFF) as u16);
                    r
                }
            }
            ASTNode::BinOp { op, left, right } => {
                let l = self.compile_expr(left);
                let r = self.compile_expr(right);
                let dst = self.alloc_reg();
                match op.as_str() {
                    "+" => self.emit(OpCode::Add as u8, dst as u16, l as u16, r as u16),
                    "-" => self.emit(OpCode::Sub as u8, dst as u16, l as u16, r as u16),
                    "*" => self.emit(OpCode::Mul as u8, dst as u16, l as u16, r as u16),
                    "/" => self.emit(OpCode::Div as u8, dst as u16, l as u16, r as u16),
                    "%" => self.emit(OpCode::Mod as u8, dst as u16, l as u16, r as u16),
                    "^" => self.emit(OpCode::Pow as u8, dst as u16, l as u16, r as u16),
                    ".." => self.emit(OpCode::Concat as u8, dst as u16, l as u16, r as u16),
                    "==" => self.emit(OpCode::Eq as u8, dst as u16, l as u16, r as u16),
                    "~=" => self.emit(OpCode::Ne as u8, dst as u16, l as u16, r as u16),
                    "<" => self.emit(OpCode::Lt as u8, dst as u16, l as u16, r as u16),
                    "<=" => self.emit(OpCode::Le as u8, dst as u16, l as u16, r as u16),
                    ">" => self.emit(OpCode::Lt as u8, dst as u16, r as u16, l as u16),
                    ">=" => self.emit(OpCode::Le as u8, dst as u16, r as u16, l as u16),
                    "and" => self.emit(OpCode::Band as u8, dst as u16, l as u16, r as u16),
                    "or" => self.emit(OpCode::Bor as u8, dst as u16, l as u16, r as u16),
                    _ => self.emit(OpCode::Add as u8, dst as u16, l as u16, r as u16),
                }
                dst
            }
            ASTNode::UnaryOp { op, operand } => {
                let src = self.compile_expr(operand);
                let dst = self.alloc_reg();
                let opcode = match op.as_str() {
                    "-" => OpCode::Unm,
                    "not" => OpCode::Not,
                    "#" => OpCode::Len,
                    _ => OpCode::Unm,
                };
                self.emit(opcode as u8, dst as u16, src as u16, 0);
                dst
            }
            ASTNode::TableConstructor(fields) => {
                let r = self.alloc_reg();
                self.emit(OpCode::NewTable as u8, r as u16, 0, 0);
                let mut array_idx = 1usize;
                for (k, v) in fields.iter() {
                    let val_reg = self.compile_expr(v);
                    if let Some(key) = k {
                        let key_reg = self.compile_expr(key);
                        self.emit(OpCode::SetTable as u8, r as u16, key_reg as u16, val_reg as u16);
                    } else {
                        let key_const = self.add_const(&array_idx.to_string(), "number");
                        let key_reg = self.alloc_reg();
                        self.emit(OpCode::LoadK as u8, key_reg as u16, (key_const >> 8) as u16, (key_const & 0xFF) as u16);
                        self.emit(OpCode::SetTable as u8, r as u16, key_reg as u16, val_reg as u16);
                        array_idx += 1;
                    }
                }
                r
            }
            ASTNode::IndexExpr { base, index } => {
                let b = self.compile_expr(base);
                let i = self.compile_expr(index);
                let r = self.alloc_reg();
                self.emit(OpCode::GetTable as u8, r as u16, b as u16, i as u16);
                r
            }
            ASTNode::MemberExpr { base, member } => {
                let b = self.compile_expr(base);
                let k = self.add_const(member, "string");
                let i = self.alloc_reg();
                self.emit(OpCode::LoadK as u8, i as u16, (k >> 8) as u16, (k & 0xFF) as u16);
                let r = self.alloc_reg();
                self.emit(OpCode::GetTable as u8, r as u16, b as u16, i as u16);
                r
            }
            ASTNode::CallExpr { func, args } => {
                let freg = self.compile_expr(func);
                let mut arg_regs = Vec::new();
                for arg in args {
                    arg_regs.push(self.compile_expr(arg));
                }
                for (i, &arg_reg) in arg_regs.iter().enumerate() {
                    let want = freg + 1 + i;
                    if arg_reg != want {
                        self.emit(OpCode::Move as u8, want as u16, arg_reg as u16, 0);
                    }
                }
                self.emit(OpCode::Call as u8, freg as u16, (arg_regs.len() + 1) as u16, 1);
                freg
            }
            ASTNode::FuncExpr { params, body } => {
                let proto_idx = self.compile_nested_proto(params, body);
                let r = self.alloc_reg();
                self.emit(OpCode::Closure as u8, r as u16, (proto_idx >> 8) as u16, (proto_idx & 0xFF) as u16);
                r
            }
            _ => {
                let r = self.alloc_reg();
                self.emit(OpCode::LoadNil as u8, r as u16, 0, 0);
                r
            }
        }
    }
}

pub fn compile_ast_to_bytecode(ast: &ASTNode) -> BytecodeFunction {
    let mut compiler = BytecodeCompiler::new(Vec::new());
    compiler.compile_function(ast)
}

#[allow(dead_code)]
fn _assert_register_capacity() {
    const _: () = assert!(MAX_REGISTERS <= u16::MAX as usize);
}
