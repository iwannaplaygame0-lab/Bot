use serenity::async_trait;
use serenity::model::gateway::Ready;
use serenity::model::channel::Message;
use serenity::prelude::*;
use serenity::builder::{CreateAttachment, CreateMessage};
use serenity::gateway::ActivityData;
use std::env;
use std::fs;
use crate::obfuscator::NothingProtectionV5;

struct Handler;

#[async_trait]
impl EventHandler for Handler {
    async fn message(&self, ctx: Context, msg: Message) {
        if msg.author.bot { return; }

        let content_trimmed = msg.content.trim().to_lowercase();

        if msg.content.starts_with("!obf") {
            let parts: Vec<&str> = msg.content.split_whitespace().collect();

            // !obf [level] [layers]
            // level defaults to "maximum", layers defaults based on level
            let level = parts.get(1).copied().unwrap_or("maximum");

            // Parse optional layer count (2nd positional arg after level)
            // Allow things like: !obf maximum 8  |  !obf vm 5  |  !obf high 4
            let layers: usize = parts.get(2)
                .and_then(|s| s.parse::<usize>().ok())
                .map(|n| n.clamp(1, 10))
                .unwrap_or(match level {
                    "basic"   => 1,
                    "high"    => 3,
                    "vm"      => 4,
                    _         => 10,  // maximum default: 2 VM + 8 encrypt layers
                });

            // Validate level
            let valid_level = matches!(level, "basic" | "high" | "vm" | "maximum");

            if let Some(attachment) = msg.attachments.first() {
                let fname = attachment.filename.to_lowercase();
                let supported = fname.ends_with(".lua")
                    || fname.ends_with(".luau")
                    || fname.ends_with(".luac")
                    || fname.ends_with(".txt");

                if !supported {
                    let _ = msg.channel_id.say(
                        &ctx.http,
                        "❌ Unsupported file type. Supported: `.lua` · `.luau` · `.luac` · `.txt`",
                    ).await;
                    return;
                }

                if !valid_level {
                    let _ = msg.channel_id.say(
                        &ctx.http,
                        "❌ Unknown level. Use: `basic` · `high` · `vm` · `maximum`",
                    ).await;
                    return;
                }

                let _ = msg.channel_id.say(&ctx.http,
                    &format!("⏳ Obfuscating with **{}** level, **{}** layers…", level, layers)
                ).await;

                let content = match attachment.download().await {
                    Ok(bytes) => String::from_utf8_lossy(&bytes).to_string(),
                    Err(_) => {
                        let _ = msg.channel_id.say(&ctx.http, "❌ Failed to download attachment.").await;
                        return;
                    }
                };

                let content_owned = content.clone();
                let level_owned   = level.to_string();

                let obf_result = tokio::task::spawn_blocking(move || {
                    std::panic::catch_unwind(move || {
                        let mut obf = NothingProtectionV5::new(&level_owned, None, None);
                        let result  = obf.obfuscate(&content_owned, layers);
                        let vm_cnt  = obf.vm_count;
                        (result, vm_cnt)
                    })
                }).await;

                let (result, vm_count) = match obf_result {
                    Ok(Ok(pair)) => pair,
                    _ => {
                        let _ = msg.channel_id.say(&ctx.http,
                            "❌ Obfuscation failed — the script may contain syntax this engine can't handle. \
                             Try `!obf high` or `!obf basic` for simpler protection."
                        ).await;
                        return;
                    }
                };

                let orig_len   = content.len();
                let result_len = result.len();
                let ratio      = result_len as f64 / orig_len.max(1) as f64;

                let out_name = format!("protected_{}", attachment.filename.replace(' ', "_"));
                let out_path = format!("/tmp/{}", out_name);

                if fs::write(&out_path, result.as_bytes()).is_err() {
                    let _ = msg.channel_id.say(&ctx.http, "❌ Failed to write output.").await;
                    return;
                }

                let level_label = match level {
                    "basic"   => "Basic (1× XOR encrypt)",
                    "high"    => "High (multi-pass XOR encrypt)",
                    "vm"      => "VM (bytecode VM + encryption)",
                    _         => "Maximum (bytecode VM + multi-layer encryption + CFG)",
                };

                let vm_info = if vm_count > 0 {
                    format!(" · VMs: `{}`", vm_count)
                } else {
                    String::new()
                };

                let cfg_count = if level == "maximum" { layers / 2 } else { 0 };
                let layer_detail = match level {
                    "maximum" => format!(
                        "**Protection breakdown:**\n\
                         • Source scramble: `1 pass` (junk lines between real code)\n\
                         • Bytecode VM: `1 layer` (custom register-VM, randomised opcodes)\n\
                         • XOR-b64 encryption: `{enc}` shells (unique random key each)\n\
                         • CFG noise: `{cfg}` layers (goto/while dispatch on alternating shells)\n\
                         • Anti-exploit: `49` executor API checks\n\
                         • Roblox guards: `6` environment assertions\n\
                         • Anti-decompiler: `9` runtime traps\n\
                         • Junk code: `24` dead functions\n\
                         • Build watermark: runtime hash verification\n\
                         > Total shells to peel: **{total}** ({enc} decrypt + 1 VM reverse)",
                        enc   = layers - 1,
                        cfg   = cfg_count,
                        total = layers,
                    ),
                    "vm" => format!(
                        "**Protection breakdown:**\n\
                         • Bytecode VM: `1 layer`\n\
                         • XOR-b64 encryption: `{enc}` shells",
                        enc = layers - 1,
                    ),
                    "high" => format!(
                        "**Protection breakdown:**\n\
                         • XOR-b64 encryption: `{enc}` shells",
                        enc = layers,
                    ),
                    _ => format!(
                        "**Protection breakdown:**\n\
                         • XOR-b64 encryption: `1` shell",
                    ),
                };

                let summary = format!(
                    "✅ **Protected!**\n\
                     Level: `{}` · Layers: `{}`{}\n\
                     Size: `{}` → `{}` (`{:.1}×`)\n\
                     {}\n\
                     > Outer shell: **no** `loadstring`/`pcall`/`bit32` strings visible — all API names recovered at runtime via char-codes.",
                    level_label, layers, vm_info,
                    fmt_size(orig_len), fmt_size(result_len), ratio,
                    layer_detail,
                );

                let ca = match CreateAttachment::path(&out_path).await {
                    Ok(a) => a,
                    Err(_) => {
                        let _ = msg.channel_id.say(&ctx.http, "❌ Failed to prepare output file.").await;
                        let _ = fs::remove_file(&out_path);
                        return;
                    }
                };

                let builder = CreateMessage::new().content(summary).add_file(ca);
                let _ = msg.channel_id.send_message(&ctx.http, builder).await;
                let _ = fs::remove_file(&out_path);

            } else {
                // No attachment — print usage
                let usage = "📎 **Attach a `.lua` / `.luau` file** and use one of:\n\n\
                    `!obf basic [layers]`   — XOR encryption (fast, 1 layer default)\n\
                    `!obf high [layers]`    — Multi-pass XOR (3 layers default)\n\
                    `!obf vm [layers]`      — Bytecode VM + encryption (4 layers default)\n\
                    `!obf maximum [layers]` — 2×VM + multi-layer + CFG (**10 layers default**, max 10)\n\n\
                    **Examples:**\n\
                    `!obf maximum` — 10-layer max protection (2 stacked VMs)\n\
                    `!obf maximum 8` — 8-layer protection (2 stacked VMs)\n\
                    `!obf vm 5` — VM + 4 encryption layers\n\n\
                    > For maximum: 2 stacked bytecode VMs (random opcode+register map) + N XOR shells\n\
                    > Guards, junk code, and watermarks are hidden **inside** the innermost layer.";
                let _ = msg.channel_id.say(&ctx.http, usage).await;
            }

        } else if content_trimmed == "!help" {
            let help = "**Nothing Protection v5** — Lua/LuaU Obfuscator\n\n\
                **Usage:** `!obf [level] [layers]` with an attached `.lua` / `.luau` file\n\n\
                **Levels:**\n\
                • `basic [1-10]` — lightweight XOR + base64 encryption\n\
                • `high [1-10]` — multi-pass XOR encryption\n\
                • `vm [1-10]` — real Lua bytecode VM (randomized opcode table)\n\
                • `maximum [1-10]` *(default)* — 2 stacked VMs + stacked encryption + CFG\n\n\
                **How layers work (maximum):**\n\
                ```\n\
                VM Layer 1 — bytecode VM, randomized opcodes + hex/binary register map\n\
                VM Layer 2 — second VM wrapping Layer 1 (layers ≥ 8)\n\
                Enc 1..N   — XOR-encrypt shells, each with a unique random key\n\
                Outer      — table-index API resolution, no rawget/string literals\n\
                ```\n\
                Everything (guards, junk, watermarks) is **inside VM Layer 1** — \
                nothing is readable in the output file.\n\n\
                **Protection features (inside the encrypted blob):**\n\
                • Exploit API detection (100+ executor globals checked)\n\
                • Roblox environment validation (game, workspace, RunService)\n\
                • Anti-decompiler traps (bit rotation, upvalue probes, hash checks)\n\
                • 24+ randomized junk functions with opaque predicates\n\
                • PRNG xorshift-32 string encryption, hex/binary register indices\n\
                • Bytecode checksum + build watermark verification\n\
                • Control-flow graph obfuscation on outer decoder\n\n\
                **Example:** `!obf maximum` — attach script for 10-layer + dual-VM protection";
            let _ = msg.channel_id.say(&ctx.http, help).await;

        } else if content_trimmed == "!ping" {
            let _ = msg.channel_id.say(&ctx.http, "🏓 Pong! NPv5 is online.").await;
        }
    }

    async fn ready(&self, ctx: Context, ready: Ready) {
        println!("[NPv5] {} is online!", ready.user.name);
        ctx.set_activity(Some(ActivityData::watching("!obf maximum 10")));
    }
}

pub async fn run_bot() {
    let token = env::var("DISCORD_BOT_TOKEN")
        .expect("DISCORD_BOT_TOKEN env var not set");
    let intents = GatewayIntents::GUILD_MESSAGES
        | GatewayIntents::DIRECT_MESSAGES
        | GatewayIntents::MESSAGE_CONTENT;
    let mut client = Client::builder(&token, intents)
        .event_handler(Handler)
        .await
        .expect("Error creating client");
    if let Err(e) = client.start().await {
        println!("[NPv5] Client error: {:?}", e);
    }
}

fn fmt_size(bytes: usize) -> String {
    if bytes < 1024 { format!("{}B", bytes) }
    else if bytes < 1024 * 1024 { format!("{:.1}KB", bytes as f64 / 1024.0) }
    else { format!("{:.1}MB", bytes as f64 / 1024.0 / 1024.0) }
}
