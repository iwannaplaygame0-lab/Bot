#[derive(Debug, Clone)]
pub enum ASTNode {
    Chunk(Vec<ASTNode>),
    LocalDecl(Vec<String>, Vec<ASTNode>),
    FuncDecl { name: String, params: Vec<String>, body: Box<ASTNode>, local: bool },
    FuncExpr { params: Vec<String>, body: Box<ASTNode> },
    IfStmt { cond: Box<ASTNode>, then_body: Box<ASTNode>, else_body: Option<Box<ASTNode>> },
    WhileStmt { cond: Box<ASTNode>, body: Box<ASTNode> },
    ForStmt { var: String, start: Box<ASTNode>, end: Box<ASTNode>, step: Option<Box<ASTNode>>, body: Box<ASTNode> },
    ForInStmt { vars: Vec<String>, iters: Vec<ASTNode>, body: Box<ASTNode> },
    DoStmt(Box<ASTNode>),
    ReturnStmt(Vec<ASTNode>),
    AssignStmt(Vec<ASTNode>, Vec<ASTNode>),
    CallExpr { func: Box<ASTNode>, args: Vec<ASTNode> },
    Literal { value: String, ltype: String },
    Ident(String),
    BinOp { op: String, left: Box<ASTNode>, right: Box<ASTNode> },
    UnaryOp { op: String, operand: Box<ASTNode> },
    TableConstructor(Vec<(Option<ASTNode>, ASTNode)>),
    IndexExpr { base: Box<ASTNode>, index: Box<ASTNode> },
    MemberExpr { base: Box<ASTNode>, member: String },
    BreakStmt,
    RepeatStmt { body: Box<ASTNode>, cond: Box<ASTNode> },
}

impl ASTNode {
    pub fn rename(&mut self, map: &std::collections::HashMap<String, String>) {
        match self {
            ASTNode::Chunk(stats) => { for s in stats { s.rename(map); } }
            ASTNode::LocalDecl(names, vals) => {
                for n in names.iter_mut() { if let Some(r) = map.get(n) { *n = r.clone(); } }
                for v in vals.iter_mut() { v.rename(map); }
            }
            ASTNode::FuncDecl { name, params, body, .. } => {
                if let Some(r) = map.get(name) { *name = r.clone(); }
                for p in params.iter_mut() { if let Some(r) = map.get(p) { *p = r.clone(); } }
                body.rename(map);
            }
            ASTNode::FuncExpr { params, body } => {
                for p in params.iter_mut() { if let Some(r) = map.get(p) { *p = r.clone(); } }
                body.rename(map);
            }
            ASTNode::IfStmt { cond, then_body, else_body } => {
                cond.rename(map);
                then_body.rename(map);
                if let Some(e) = else_body { e.rename(map); }
            }
            ASTNode::WhileStmt { cond, body } => { cond.rename(map); body.rename(map); }
            ASTNode::ForStmt { var, start, end, step, body } => {
                if let Some(r) = map.get(var) { *var = r.clone(); }
                start.rename(map); end.rename(map);
                if let Some(s) = step { s.rename(map); }
                body.rename(map);
            }
            ASTNode::ForInStmt { vars, iters, body } => {
                for v in vars.iter_mut() { if let Some(r) = map.get(v) { *v = r.clone(); } }
                for it in iters.iter_mut() { it.rename(map); }
                body.rename(map);
            }
            ASTNode::DoStmt(body) => { body.rename(map); }
            ASTNode::ReturnStmt(vals) => { for v in vals.iter_mut() { v.rename(map); } }
            ASTNode::AssignStmt(targets, vals) => {
                for t in targets.iter_mut() { t.rename(map); }
                for v in vals.iter_mut() { v.rename(map); }
            }
            ASTNode::CallExpr { func, args } => {
                func.rename(map);
                for a in args.iter_mut() { a.rename(map); }
            }
            ASTNode::Literal { .. } => {}
            ASTNode::Ident(name) => { if let Some(r) = map.get(name) { *name = r.clone(); } }
            ASTNode::BinOp { left, right, .. } => { left.rename(map); right.rename(map); }
            ASTNode::UnaryOp { operand, .. } => { operand.rename(map); }
            ASTNode::TableConstructor(fields) => {
                for (k, v) in fields.iter_mut() {
                    if let Some(kn) = k { kn.rename(map); }
                    v.rename(map);
                }
            }
            ASTNode::IndexExpr { base, index } => { base.rename(map); index.rename(map); }
            ASTNode::MemberExpr { base, .. } => { base.rename(map); }
            ASTNode::BreakStmt => {}
            ASTNode::RepeatStmt { body, cond } => { body.rename(map); cond.rename(map); }
        }
    }

    pub fn collect_local_names(&self, out: &mut std::collections::HashSet<String>) {
        match self {
            ASTNode::Chunk(stats) => { for s in stats { s.collect_local_names(out); } }
            ASTNode::LocalDecl(names, vals) => {
                for n in names { out.insert(n.clone()); }
                for v in vals { v.collect_local_names(out); }
            }
            ASTNode::FuncDecl { name, params, body, local } => {
                if *local { out.insert(name.clone()); }
                for p in params { out.insert(p.clone()); }
                body.collect_local_names(out);
            }
            ASTNode::FuncExpr { params, body } => {
                for p in params { out.insert(p.clone()); }
                body.collect_local_names(out);
            }
            ASTNode::IfStmt { cond, then_body, else_body } => {
                cond.collect_local_names(out);
                then_body.collect_local_names(out);
                if let Some(e) = else_body { e.collect_local_names(out); }
            }
            ASTNode::WhileStmt { cond, body } => { cond.collect_local_names(out); body.collect_local_names(out); }
            ASTNode::ForStmt { var, start, end, step, body } => {
                out.insert(var.clone());
                start.collect_local_names(out); end.collect_local_names(out);
                if let Some(s) = step { s.collect_local_names(out); }
                body.collect_local_names(out);
            }
            ASTNode::ForInStmt { vars, iters, body } => {
                for v in vars { out.insert(v.clone()); }
                for it in iters { it.collect_local_names(out); }
                body.collect_local_names(out);
            }
            ASTNode::DoStmt(body) => { body.collect_local_names(out); }
            ASTNode::ReturnStmt(vals) => { for v in vals { v.collect_local_names(out); } }
            ASTNode::AssignStmt(targets, vals) => {
                for t in targets { t.collect_local_names(out); }
                for v in vals { v.collect_local_names(out); }
            }
            ASTNode::CallExpr { func, args } => {
                func.collect_local_names(out);
                for a in args { a.collect_local_names(out); }
            }
            ASTNode::BinOp { left, right, .. } => { left.collect_local_names(out); right.collect_local_names(out); }
            ASTNode::UnaryOp { operand, .. } => { operand.collect_local_names(out); }
            ASTNode::TableConstructor(fields) => {
                for (k, v) in fields {
                    if let Some(kn) = k { kn.collect_local_names(out); }
                    v.collect_local_names(out);
                }
            }
            ASTNode::IndexExpr { base, index } => { base.collect_local_names(out); index.collect_local_names(out); }
            ASTNode::MemberExpr { base, .. } => { base.collect_local_names(out); }
            ASTNode::RepeatStmt { body, cond } => { body.collect_local_names(out); cond.collect_local_names(out); }
            ASTNode::Literal { .. } | ASTNode::Ident(_) | ASTNode::BreakStmt => {}
        }
    }

    pub fn mutate_arith(&mut self, rng: &mut impl rand::Rng) {
        match self {
            ASTNode::BinOp { op, left, right } => {
                left.mutate_arith(rng);
                right.mutate_arith(rng);
                if op == "+" && rng.gen_bool(0.5) {
                    let l = left.clone(); let r = right.clone();
                    *self = ASTNode::BinOp {
                        op: "/".into(),
                        left: Box::new(ASTNode::BinOp {
                            op: "+".into(),
                            left: Box::new(ASTNode::BinOp { op: "*".into(), left: l, right: Box::new(ASTNode::Literal { value: "2".into(), ltype: "number".into() }) }),
                            right: Box::new(ASTNode::BinOp { op: "*".into(), left: r, right: Box::new(ASTNode::Literal { value: "2".into(), ltype: "number".into() }) }),
                        }),
                        right: Box::new(ASTNode::Literal { value: "2".into(), ltype: "number".into() }),
                    };
                } else if op == "-" && rng.gen_bool(0.5) {
                    let l = left.clone(); let r = right.clone();
                    *self = ASTNode::BinOp {
                        op: "/".into(),
                        left: Box::new(ASTNode::BinOp {
                            op: "-".into(),
                            left: Box::new(ASTNode::BinOp { op: "*".into(), left: l, right: Box::new(ASTNode::Literal { value: "3".into(), ltype: "number".into() }) }),
                            right: Box::new(ASTNode::BinOp { op: "*".into(), left: r, right: Box::new(ASTNode::Literal { value: "3".into(), ltype: "number".into() }) }),
                        }),
                        right: Box::new(ASTNode::Literal { value: "3".into(), ltype: "number".into() }),
                    };
                }
            }
            ASTNode::UnaryOp { operand, .. } => operand.mutate_arith(rng),
            ASTNode::Chunk(stats) => { for s in stats { s.mutate_arith(rng); } }
            ASTNode::LocalDecl(_, vals) => { for v in vals { v.mutate_arith(rng); } }
            ASTNode::FuncDecl { body, .. } => body.mutate_arith(rng),
            ASTNode::FuncExpr { body, .. } => body.mutate_arith(rng),
            ASTNode::IfStmt { cond, then_body, else_body } => {
                cond.mutate_arith(rng); then_body.mutate_arith(rng);
                if let Some(e) = else_body { e.mutate_arith(rng); }
            }
            ASTNode::WhileStmt { cond, body } => { cond.mutate_arith(rng); body.mutate_arith(rng); }
            ASTNode::ForStmt { start, end, step, body, .. } => {
                start.mutate_arith(rng); end.mutate_arith(rng);
                if let Some(s) = step { s.mutate_arith(rng); }
                body.mutate_arith(rng);
            }
            ASTNode::ForInStmt { iters, body, .. } => {
                for it in iters { it.mutate_arith(rng); }
                body.mutate_arith(rng);
            }
            ASTNode::DoStmt(body) => { body.mutate_arith(rng); }
            ASTNode::ReturnStmt(vals) => { for v in vals { v.mutate_arith(rng); } }
            ASTNode::AssignStmt(_, vals) => { for v in vals { v.mutate_arith(rng); } }
            ASTNode::CallExpr { func, args } => {
                func.mutate_arith(rng);
                for a in args { a.mutate_arith(rng); }
            }
            ASTNode::TableConstructor(fields) => {
                for (k, v) in fields {
                    if let Some(kn) = k { kn.mutate_arith(rng); }
                    v.mutate_arith(rng);
                }
            }
            ASTNode::IndexExpr { base, index } => { base.mutate_arith(rng); index.mutate_arith(rng); }
            ASTNode::MemberExpr { base, .. } => base.mutate_arith(rng),
            ASTNode::RepeatStmt { body, cond } => { body.mutate_arith(rng); cond.mutate_arith(rng); }
            ASTNode::Literal { .. } | ASTNode::Ident(_) | ASTNode::BreakStmt => {}
        }
    }

    pub fn to_lua(&self) -> String {
        match self {
            ASTNode::Chunk(stats) => stats.iter().map(|s| s.to_lua()).collect::<Vec<_>>().join("\n"),
            ASTNode::LocalDecl(names, vals) => {
                let n = names.join(", ");
                if vals.is_empty() { format!("local {}", n) }
                else { format!("local {} = {}", n, vals.iter().map(|v| v.to_lua()).collect::<Vec<_>>().join(", ")) }
            }
            ASTNode::FuncDecl { name, params, body, local } => {
                let prefix = if *local { "local " } else { "" };
                format!("{}function {}({})\n{}\nend", prefix, name, params.join(", "), body.to_lua())
            }
            ASTNode::FuncExpr { params, body } => {
                format!("function({})\n{}\nend", params.join(", "), body.to_lua())
            }
            ASTNode::IfStmt { cond, then_body, else_body } => {
                let mut s = format!("if {} then\n{}", cond.to_lua(), then_body.to_lua());
                if let Some(e) = else_body { s.push_str(&format!("\nelse\n{}", e.to_lua())); }
                s.push_str("\nend");
                s
            }
            ASTNode::WhileStmt { cond, body } => format!("while {} do\n{}\nend", cond.to_lua(), body.to_lua()),
            ASTNode::ForStmt { var, start, end, step, body } => {
                let mut s = format!("for {} = {}, {}", var, start.to_lua(), end.to_lua());
                if let Some(st) = step { s.push_str(&format!(", {}", st.to_lua())); }
                s.push_str(&format!(" do\n{}\nend", body.to_lua()));
                s
            }
            ASTNode::ForInStmt { vars, iters, body } => {
                format!("for {} in {} do\n{}\nend",
                    vars.join(", "),
                    iters.iter().map(|i| i.to_lua()).collect::<Vec<_>>().join(", "),
                    body.to_lua())
            }
            ASTNode::DoStmt(body) => format!("do\n{}\nend", body.to_lua()),
            ASTNode::ReturnStmt(vals) => {
                if vals.is_empty() { "return".to_string() }
                else { format!("return {}", vals.iter().map(|v| v.to_lua()).collect::<Vec<_>>().join(", ")) }
            }
            ASTNode::AssignStmt(targets, vals) => format!("{} = {}",
                targets.iter().map(|t| t.to_lua()).collect::<Vec<_>>().join(", "),
                vals.iter().map(|v| v.to_lua()).collect::<Vec<_>>().join(", ")),
            ASTNode::CallExpr { func, args } => {
                format!("{}({})", func.to_lua(), args.iter().map(|a| a.to_lua()).collect::<Vec<_>>().join(", "))
            }
            ASTNode::Literal { value, .. } => value.clone(),
            ASTNode::Ident(name) => name.clone(),
            ASTNode::BinOp { op, left, right } => format!("({} {} {})", left.to_lua(), op, right.to_lua()),
            ASTNode::UnaryOp { op, operand } => format!("({}{})", op, operand.to_lua()),
            ASTNode::TableConstructor(fields) => {
                let items: Vec<String> = fields.iter().map(|(k, v)| {
                    if let Some(kn) = k { format!("[{}] = {}", kn.to_lua(), v.to_lua()) }
                    else { v.to_lua() }
                }).collect();
                format!("{{{}}}", items.join(", "))
            }
            ASTNode::IndexExpr { base, index } => format!("{}[{}]", base.to_lua(), index.to_lua()),
            ASTNode::MemberExpr { base, member } => format!("{}.{}", base.to_lua(), member),
            ASTNode::BreakStmt => "break".to_string(),
            ASTNode::RepeatStmt { body, cond } => format!("repeat\n{}\nuntil {}", body.to_lua(), cond.to_lua()),
        }
    }
}
