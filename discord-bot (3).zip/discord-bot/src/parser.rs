use crate::tokenizer::{Token, TokenType};
use crate::ast::ASTNode;

pub struct LuaParser {
    tokens: Vec<Token>,
    pos: usize,
}

impl LuaParser {
    pub fn new(tokens: Vec<Token>) -> Self {
        Self { tokens, pos: 0 }
    }

    pub fn parse(&mut self) -> ASTNode {
        self.parse_chunk()
    }

    fn peek(&self, offset: usize) -> &Token {
        &self.tokens[(self.pos + offset).min(self.tokens.len() - 1)]
    }

    fn advance(&mut self) -> Token {
        let t = self.tokens[self.pos.min(self.tokens.len() - 1)].clone();
        if self.pos < self.tokens.len() - 1 { self.pos += 1; }
        t
    }

    fn expect_kw(&mut self, kw: &str) {
        if self.peek(0).ty == TokenType::Keyword && self.peek(0).val == kw {
            self.advance();
        }
    }

    fn expect_sym(&mut self, sym: &str) {
        if self.peek(0).ty == TokenType::Symbol && self.peek(0).val == sym {
            self.advance();
        }
    }

    fn match_kw(&self, kw: &str) -> bool {
        self.peek(0).ty == TokenType::Keyword && self.peek(0).val == kw
    }

    fn match_sym(&self, sym: &str) -> bool {
        self.peek(0).ty == TokenType::Symbol && self.peek(0).val == sym
    }

    fn is_block_end(&self) -> bool {
        if self.peek(0).ty == TokenType::Eof { return true; }
        if self.peek(0).ty == TokenType::Keyword {
            let v = self.peek(0).val.as_str();
            matches!(v, "end" | "else" | "elseif" | "until")
        } else {
            false
        }
    }

    fn parse_chunk(&mut self) -> ASTNode {
        let mut stats = Vec::new();
        while !self.is_block_end() {
            if self.match_kw("return") {
                stats.push(self.parse_return());
                if self.match_sym(";") { self.advance(); }
                break;
            }
            if self.match_sym(";") { self.advance(); continue; }
            let pos_before = self.pos;
            if let Some(stat) = self.parse_stat() {
                stats.push(stat);
            }
            if self.match_sym(";") { self.advance(); }
            if self.pos == pos_before { self.advance(); }
        }
        ASTNode::Chunk(stats)
    }

    fn parse_stat(&mut self) -> Option<ASTNode> {
        if self.match_kw("local") {
            return Some(self.parse_local());
        }
        if self.match_kw("function") {
            return Some(self.parse_func_decl());
        }
        if self.match_kw("if") {
            return Some(self.parse_if());
        }
        if self.match_kw("while") {
            return Some(self.parse_while());
        }
        if self.match_kw("for") {
            return Some(self.parse_for());
        }
        if self.match_kw("repeat") {
            return Some(self.parse_repeat());
        }
        if self.match_kw("do") {
            self.advance();
            let body = self.parse_chunk();
            self.expect_kw("end");
            return Some(ASTNode::DoStmt(Box::new(body)));
        }
        if self.match_kw("break") {
            self.advance();
            return Some(ASTNode::BreakStmt);
        }
        if self.match_kw("goto") {
            self.advance();
            if self.peek(0).ty == TokenType::Ident { self.advance(); }
            return None;
        }
        if self.match_sym("::") {
            self.advance();
            if self.peek(0).ty == TokenType::Ident { self.advance(); }
            self.expect_sym("::");
            return None;
        }

        let expr = self.parse_expr();

        if self.match_sym("=") {
            self.advance();
            let vals = self.parse_expr_list();
            return Some(ASTNode::AssignStmt(vec![expr], vals));
        }
        if self.match_sym(",") {
            let mut targets = vec![expr];
            while self.match_sym(",") {
                self.advance();
                targets.push(self.parse_expr());
            }
            if self.match_sym("=") {
                self.advance();
                let vals = self.parse_expr_list();
                return Some(ASTNode::AssignStmt(targets, vals));
            }
            return Some(ASTNode::Chunk(targets));
        }
        Some(expr)
    }

    fn parse_local(&mut self) -> ASTNode {
        self.expect_kw("local");
        if self.match_kw("function") {
            self.expect_kw("function");
            let name = if self.peek(0).ty == TokenType::Ident { self.advance().val } else { "_".into() };
            let params = self.parse_param_list();
            let body = Box::new(self.parse_chunk());
            self.expect_kw("end");
            return ASTNode::FuncDecl { name, params, body, local: true };
        }
        let names = self.parse_name_list();
        let mut vals = Vec::new();
        if self.match_sym("=") {
            self.advance();
            vals = self.parse_expr_list();
        }
        ASTNode::LocalDecl(names, vals)
    }

    fn parse_func_decl(&mut self) -> ASTNode {
        self.expect_kw("function");
        let mut name = if self.peek(0).ty == TokenType::Ident { self.advance().val } else { "_".into() };
        while self.match_sym(".") {
            self.advance();
            if self.peek(0).ty == TokenType::Ident {
                let part = self.advance().val;
                name = format!("{}.{}", name, part);
            }
        }
        if self.match_sym(":") {
            self.advance();
            if self.peek(0).ty == TokenType::Ident {
                let part = self.advance().val;
                name = format!("{}:{}", name, part);
            }
        }
        let params = self.parse_param_list();
        let body = Box::new(self.parse_chunk());
        self.expect_kw("end");
        ASTNode::FuncDecl { name, params, body, local: false }
    }

    fn parse_func_expr(&mut self) -> ASTNode {
        self.expect_kw("function");
        let params = self.parse_param_list();
        let body = Box::new(self.parse_chunk());
        self.expect_kw("end");
        ASTNode::FuncExpr { params, body }
    }

    fn parse_param_list(&mut self) -> Vec<String> {
        self.expect_sym("(");
        let mut params = Vec::new();
        while !self.match_sym(")") && self.peek(0).ty != TokenType::Eof {
            if self.peek(0).ty == TokenType::Ident {
                params.push(self.advance().val);
            } else if self.match_sym("...") {
                params.push("...".into());
                self.advance();
                break;
            } else {
                self.advance();
            }
            if self.match_sym(",") { self.advance(); } else { break; }
        }
        self.expect_sym(")");
        params
    }

    fn parse_name_list(&mut self) -> Vec<String> {
        let mut names = Vec::new();
        if self.peek(0).ty == TokenType::Ident {
            names.push(self.advance().val);
            while self.match_sym(",") && self.peek(1).ty == TokenType::Ident {
                self.advance();
                names.push(self.advance().val);
            }
        }
        names
    }

    fn parse_if(&mut self) -> ASTNode {
        self.expect_kw("if");
        let cond = Box::new(self.parse_expr());
        self.expect_kw("then");
        let then_body = Box::new(self.parse_chunk());
        let else_body = if self.match_kw("elseif") {
            Some(Box::new(self.parse_if()))
        } else if self.match_kw("else") {
            self.advance();
            Some(Box::new(self.parse_chunk()))
        } else {
            None
        };
        self.expect_kw("end");
        ASTNode::IfStmt { cond, then_body, else_body }
    }

    fn parse_while(&mut self) -> ASTNode {
        self.expect_kw("while");
        let cond = Box::new(self.parse_expr());
        self.expect_kw("do");
        let body = Box::new(self.parse_chunk());
        self.expect_kw("end");
        ASTNode::WhileStmt { cond, body }
    }

    fn parse_for(&mut self) -> ASTNode {
        self.expect_kw("for");
        let first_var = if self.peek(0).ty == TokenType::Ident { self.advance().val } else { "_".into() };

        if self.match_sym("=") {
            self.advance();
            let start = Box::new(self.parse_expr());
            self.expect_sym(",");
            let end = Box::new(self.parse_expr());
            let step = if self.match_sym(",") { self.advance(); Some(Box::new(self.parse_expr())) } else { None };
            self.expect_kw("do");
            let body = Box::new(self.parse_chunk());
            self.expect_kw("end");
            ASTNode::ForStmt { var: first_var, start, end, step, body }
        } else {
            let mut vars = vec![first_var];
            while self.match_sym(",") {
                self.advance();
                if self.peek(0).ty == TokenType::Ident { vars.push(self.advance().val); }
            }
            self.expect_kw("in");
            let iters = self.parse_expr_list();
            self.expect_kw("do");
            let body = Box::new(self.parse_chunk());
            self.expect_kw("end");
            ASTNode::ForInStmt { vars, iters, body }
        }
    }

    fn parse_repeat(&mut self) -> ASTNode {
        self.expect_kw("repeat");
        let body = Box::new(self.parse_chunk());
        self.expect_kw("until");
        let cond = Box::new(self.parse_expr());
        ASTNode::RepeatStmt { body, cond }
    }

    fn parse_return(&mut self) -> ASTNode {
        self.expect_kw("return");
        if self.is_block_end() || self.match_sym(";") {
            return ASTNode::ReturnStmt(Vec::new());
        }
        ASTNode::ReturnStmt(self.parse_expr_list())
    }

    fn parse_expr_list(&mut self) -> Vec<ASTNode> {
        let mut exprs = vec![self.parse_expr()];
        while self.match_sym(",") {
            self.advance();
            exprs.push(self.parse_expr());
        }
        exprs
    }

    fn parse_expr(&mut self) -> ASTNode { self.parse_or() }

    fn parse_or(&mut self) -> ASTNode {
        let mut left = self.parse_and();
        while self.match_kw("or") {
            self.advance();
            left = ASTNode::BinOp { op: "or".into(), left: Box::new(left), right: Box::new(self.parse_and()) };
        }
        left
    }

    fn parse_and(&mut self) -> ASTNode {
        let mut left = self.parse_rel();
        while self.match_kw("and") {
            self.advance();
            left = ASTNode::BinOp { op: "and".into(), left: Box::new(left), right: Box::new(self.parse_rel()) };
        }
        left
    }

    fn parse_rel(&mut self) -> ASTNode {
        let left = self.parse_concat();
        if self.peek(0).ty == TokenType::Symbol {
            let op = self.peek(0).val.clone();
            if ["<", ">", "<=", ">=", "==", "~="].contains(&op.as_str()) {
                self.advance();
                return ASTNode::BinOp { op, left: Box::new(left), right: Box::new(self.parse_concat()) };
            }
        }
        left
    }

    fn parse_concat(&mut self) -> ASTNode {
        let left = self.parse_add();
        if self.match_sym("..") {
            self.advance();
            let right = self.parse_concat();
            return ASTNode::BinOp { op: "..".into(), left: Box::new(left), right: Box::new(right) };
        }
        left
    }

    fn parse_add(&mut self) -> ASTNode {
        let mut left = self.parse_mul();
        while self.peek(0).ty == TokenType::Symbol && (self.peek(0).val == "+" || self.peek(0).val == "-") {
            let op = self.advance().val;
            left = ASTNode::BinOp { op, left: Box::new(left), right: Box::new(self.parse_mul()) };
        }
        left
    }

    fn parse_mul(&mut self) -> ASTNode {
        let mut left = self.parse_unary();
        while self.peek(0).ty == TokenType::Symbol {
            let op = self.peek(0).val.clone();
            if op == "*" || op == "/" || op == "%" || op == "//" {
                self.advance();
                left = ASTNode::BinOp { op, left: Box::new(left), right: Box::new(self.parse_unary()) };
            } else { break; }
        }
        left
    }

    fn parse_unary(&mut self) -> ASTNode {
        if self.match_sym("-") || self.match_sym("#") {
            let op = self.advance().val;
            return ASTNode::UnaryOp { op, operand: Box::new(self.parse_unary()) };
        }
        if self.match_kw("not") {
            self.advance();
            return ASTNode::UnaryOp { op: "not".into(), operand: Box::new(self.parse_unary()) };
        }
        self.parse_power()
    }

    fn parse_power(&mut self) -> ASTNode {
        let left = self.parse_postfix();
        if self.match_sym("^") {
            self.advance();
            let right = self.parse_unary();
            return ASTNode::BinOp { op: "^".into(), left: Box::new(left), right: Box::new(right) };
        }
        left
    }

    fn parse_postfix(&mut self) -> ASTNode {
        let mut node = self.parse_primary();
        loop {
            if self.match_sym(".") {
                self.advance();
                let member = if self.peek(0).ty == TokenType::Ident { self.advance().val } else { break };
                node = ASTNode::MemberExpr { base: Box::new(node), member };
            } else if self.match_sym(":") {
                self.advance();
                let method = if self.peek(0).ty == TokenType::Ident { self.advance().val } else { break };
                let args = self.parse_call_args();
                node = ASTNode::CallExpr {
                    func: Box::new(ASTNode::MemberExpr { base: Box::new(node), member: method }),
                    args,
                };
            } else if self.match_sym("[") {
                self.advance();
                let idx = self.parse_expr();
                self.expect_sym("]");
                node = ASTNode::IndexExpr { base: Box::new(node), index: Box::new(idx) };
            } else if self.match_sym("(") {
                let args = self.parse_call_args();
                node = ASTNode::CallExpr { func: Box::new(node), args };
            } else if self.peek(0).ty == TokenType::String {
                let s = self.advance().val;
                node = ASTNode::CallExpr {
                    func: Box::new(node),
                    args: vec![ASTNode::Literal { value: s, ltype: "string".into() }],
                };
            } else if self.match_sym("{") {
                let tbl = self.parse_table();
                node = ASTNode::CallExpr { func: Box::new(node), args: vec![tbl] };
            } else {
                break;
            }
        }
        node
    }

    fn parse_call_args(&mut self) -> Vec<ASTNode> {
        if self.match_sym("(") {
            self.advance();
            if self.match_sym(")") { self.advance(); return Vec::new(); }
            let args = self.parse_expr_list();
            self.expect_sym(")");
            args
        } else if self.peek(0).ty == TokenType::String {
            let s = self.advance().val;
            vec![ASTNode::Literal { value: s, ltype: "string".into() }]
        } else if self.match_sym("{") {
            vec![self.parse_table()]
        } else {
            Vec::new()
        }
    }

    fn parse_primary(&mut self) -> ASTNode {
        if self.peek(0).ty == TokenType::Number {
            return ASTNode::Literal { value: self.advance().val, ltype: "number".into() };
        }
        if self.peek(0).ty == TokenType::String {
            return ASTNode::Literal { value: self.advance().val, ltype: "string".into() };
        }
        if self.match_kw("true")  { self.advance(); return ASTNode::Literal { value: "true".into(), ltype: "bool".into() }; }
        if self.match_kw("false") { self.advance(); return ASTNode::Literal { value: "false".into(), ltype: "bool".into() }; }
        if self.match_kw("nil")   { self.advance(); return ASTNode::Literal { value: "nil".into(), ltype: "nil".into() }; }
        if self.match_sym("...") {
            self.advance();
            return ASTNode::Literal { value: "...".into(), ltype: "vararg".into() };
        }
        if self.match_kw("function") {
            return self.parse_func_expr();
        }
        if self.match_sym("{") {
            return self.parse_table();
        }
        if self.match_sym("(") {
            self.advance();
            let expr = self.parse_expr();
            self.expect_sym(")");
            return expr;
        }
        if self.peek(0).ty == TokenType::Ident {
            let name = self.advance().val;
            return ASTNode::Ident(name);
        }
        ASTNode::Literal { value: "nil".into(), ltype: "nil".into() }
    }

    fn parse_table(&mut self) -> ASTNode {
        self.expect_sym("{");
        let mut fields = Vec::new();
        while !self.match_sym("}") && self.peek(0).ty != TokenType::Eof {
            if self.match_sym("[") {
                self.advance();
                let key = self.parse_expr();
                self.expect_sym("]");
                self.expect_sym("=");
                let val = self.parse_expr();
                fields.push((Some(key), val));
            } else if self.peek(0).ty == TokenType::Ident && self.peek(1).ty == TokenType::Symbol && self.peek(1).val == "=" {
                let key = ASTNode::Literal { value: self.advance().val, ltype: "string".into() };
                self.advance();
                let val = self.parse_expr();
                fields.push((Some(key), val));
            } else {
                let val = self.parse_expr();
                fields.push((None, val));
            }
            if self.match_sym(",") || self.match_sym(";") { self.advance(); } else { break; }
        }
        self.expect_sym("}");
        ASTNode::TableConstructor(fields)
    }
}
