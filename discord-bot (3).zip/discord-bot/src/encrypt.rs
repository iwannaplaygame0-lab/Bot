use rand::Rng;
use sha2::{Sha256, Digest};

pub struct XTEA {
    key: [u32; 4],
    rounds: u32,
}

impl XTEA {
    pub fn new(key: [u32; 4], rounds: u32) -> Self {
        Self { key, rounds }
    }

    pub fn encrypt(&self, data: &[u8]) -> Vec<u8> {
        let mut out = Vec::new();
        let padded = Self::pad(data);
        for chunk in padded.chunks_exact(8) {
            let v0 = u32::from_le_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
            let v1 = u32::from_le_bytes([chunk[4], chunk[5], chunk[6], chunk[7]]);
            let (e0, e1) = self.encrypt_block(v0, v1);
            out.extend_from_slice(&e0.to_le_bytes());
            out.extend_from_slice(&e1.to_le_bytes());
        }
        out
    }

    fn encrypt_block(&self, mut v0: u32, mut v1: u32) -> (u32, u32) {
        let mut sum: u32 = 0;
        let delta: u32 = 0x9E3779B9;
        for _ in 0..self.rounds {
            sum = sum.wrapping_add(delta);
            v0 = v0.wrapping_add(
                (((v1.wrapping_shl(4)) ^ (v1.wrapping_shr(5))).wrapping_add(v1))
                    ^ sum.wrapping_add(self.key[(sum.wrapping_shr(11) & 3) as usize])
            );
            v1 = v1.wrapping_add(
                (((v0.wrapping_shl(4)) ^ (v0.wrapping_shr(5))).wrapping_add(v0))
                    ^ sum.wrapping_add(self.key[(sum & 3) as usize])
            );
        }
        (v0, v1)
    }

    fn pad(data: &[u8]) -> Vec<u8> {
        let mut v = data.to_vec();
        let pad = 8 - (v.len() % 8);
        if pad != 8 {
            v.extend(std::iter::repeat(0u8).take(pad));
        }
        v
    }
}

pub fn xor_encrypt(data: &[u8], key: u8) -> Vec<u8> {
    data.iter().enumerate().map(|(i, b)| b ^ key.wrapping_add(i as u8)).collect()
}

pub fn generate_key_bytes(len: usize) -> Vec<u8> {
    let mut rng = rand::thread_rng();
    (0..len).map(|_| rng.gen::<u8>()).collect()
}

pub fn sha256_bytes(data: &[u8]) -> Vec<u8> {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hasher.finalize().to_vec()
}
