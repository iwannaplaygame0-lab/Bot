use rand::Rng;

pub struct Watermarker {
    build_id: String,
    customer_id: u32,
    rng: rand::rngs::ThreadRng,
}

impl Watermarker {
    pub fn new(build_id: &str, customer_id: u32) -> Self {
        Self { build_id: build_id.to_string(), customer_id, rng: rand::thread_rng() }
    }

    pub fn generate_lua_checks(&mut self) -> String {
        let mut checks = Vec::new();

        // Pre-compute expected hash in Rust
        let mut h: u32 = 0;
        for b in self.build_id.bytes() {
            h = h.wrapping_mul(31).wrapping_add(b as u32) & 0x7FFFFFFF;
        }
        h = h.wrapping_add(self.customer_id.wrapping_mul(47)) & 0x7FFFFFFF;
        let hash_sum = h;

        // Obfuscated names
        let v1  = self.gen_name();
        let vb  = self.gen_name();
        let vc  = self.gen_name();
        let vh  = self.gen_name();
        let vi  = self.gen_name();
        let vb3 = self.gen_name(); // bit32 alias
        let vst = self.gen_name(); // string alias
        let vsb = self.gen_name(); // string.byte alias
        let vbd = self.gen_name(); // bit32.band alias
        let vmul= self.gen_name(); // mul alias (hidden constant)

        // Encode "band" and "byte" as char sequences
        let band_cc = "98,97,110,100";       // "band"
        let byte_cc = "98,121,116,101";      // "byte"

        let bid_escaped: String = self.build_id.bytes()
            .map(|b| format!("\\{}", b))
            .collect();

        checks.push(format!(
r#"local {v1}=function()
local {vst}=string local {vb3}=bit32
local {vsb}={vst}[{vst}.char({byte_cc})]
local {vbd}={vb3}[{vst}.char({band_cc})]
local {vb}="{bid}"
local {vc}={cid}
local {vh}=0
for {vi}=1,#{vb} do
{vh}={vbd}({vh}*31+{vsb}({vb},{vi}),2147483647)
end
{vh}={vbd}({vh}+{vc}*47,2147483647)
if {vh}~={hsum} then repeat until false end
end
{v1}()
"#,
            v1=v1, vst=vst, vb3=vb3, vsb=vsb, vbd=vbd,
            vb=vb, vc=vc, vh=vh, vi=vi,
            bid=bid_escaped, cid=self.customer_id, hsum=hash_sum,
            byte_cc=byte_cc, band_cc=band_cc,
        ));

        // Second check: random bit-mask verification (opaque predicate style)
        let wm_val: u32 = self.rng.gen();
        let mask: u32 = self.rng.gen();
        let expected = wm_val & mask;
        let v3  = self.gen_name();
        let vwm = self.gen_name();
        let vmk = self.gen_name();
        let vb32b = self.gen_name();
        let vst2 = self.gen_name();
        let vbnd = self.gen_name();

        checks.push(format!(
r#"local {v3}=function()
local {vst2}=string local {vb32b}=bit32
local {vbnd}={vb32b}[{vst2}.char({band_cc})]
local {vwm}={wm}
local {vmk}={mask}
if {vbnd}({vwm},{vmk})~={exp} then repeat until false end
end
{v3}()
"#,
            v3=v3, vst2=vst2, vb32b=vb32b, vbnd=vbnd,
            vwm=vwm, vmk=vmk,
            wm=wm_val, mask=mask, exp=expected,
            band_cc=band_cc,
        ));

        // Third check: NothingProtection brand string hash — hidden as char codes
        let brand = "NothingProtection";
        let brand_cc: String = brand.bytes().map(|b| b.to_string()).collect::<Vec<_>>().join(",");
        let mut bh: u32 = 0;
        for b in brand.bytes() { bh = bh.wrapping_mul(31).wrapping_add(b as u32) & 0x7FFFFFFF; }
        let v4   = self.gen_name();
        let vhh  = self.gen_name();
        let vii  = self.gen_name();
        let vst3 = self.gen_name();
        let vb3c = self.gen_name();
        let vsbr = self.gen_name();
        let vbdc = self.gen_name();
        let vbr  = self.gen_name();

        checks.push(format!(
r#"local {v4}=function()
local {vst3}=string local {vb3c}=bit32
local {vsbr}={vst3}[{vst3}.char({byte_cc})]
local {vbdc}={vb3c}[{vst3}.char({band_cc})]
local {vbr}={vst3}.char({brand_cc})
local {vhh}=0
for {vii}=1,#{vbr} do
{vhh}={vbdc}({vhh}*31+{vsbr}({vbr},{vii}),2147483647)
end
if {vhh}~={bh} then repeat until false end
end
"#,
            v4=v4, vst3=vst3, vb3c=vb3c, vsbr=vsbr, vbdc=vbdc,
            vmul=vmul, vbr=vbr, vhh=vhh, vii=vii,
            brand_cc=brand_cc, bh=bh,
            byte_cc=byte_cc, band_cc=band_cc,
        ));
        // Note: v4 is defined but intentionally not called — it's a decoy trap

        checks.join("\n")
    }

    fn gen_name(&mut self) -> String {
        let chars: &[u8] = b"Il1lO0Qq_o";
        let len = self.rng.gen_range(9..15usize);
        let mut name = String::from("_");
        for _ in 0..len {
            name.push(chars[self.rng.gen_range(0..chars.len())] as char);
        }
        name
    }
}
