use rand::Rng;
use crate::bytecode::{BytecodeFunction, Constant, OpCode, UpvalSource, OPCODE_COUNT};

pub struct VMGenerator {
    pub vm_id: usize,
    rng: rand::rngs::ThreadRng,
    op_map: Vec<u8>,
    layer_keys: Vec<u8>,
    watermark: u64,
    customer_id: u32,
    prng_seed: u32,
    prng_table: Vec<u8>,
    reg_map: Vec<u32>,
}

impl VMGenerator {
    pub fn new(vm_id: usize, customer_id: u32) -> Self {
        let mut rng = rand::thread_rng();
        let mut op_map: Vec<u8> = (0..OPCODE_COUNT as u8).collect();
        Self::shuffle_u8(&mut op_map, &mut rng);
        let layer_keys: Vec<u8> = (0..3).map(|_| rng.gen()).collect();
        let watermark = rng.gen::<u64>();
        let prng_seed: u32 = rng.gen_range(1..=u32::MAX);
        let prng_table = Self::build_xorshift_table(prng_seed);
        // 256 unique physical register indices (3000..30000) — looks like real memory addresses
        let mut reg_set = std::collections::HashSet::new();
        let mut reg_map = Vec::with_capacity(256);
        while reg_map.len() < 256 {
            let v: u32 = rng.gen_range(3000..30000u32);
            if reg_set.insert(v) { reg_map.push(v); }
        }
        Self { vm_id, rng, op_map, layer_keys, watermark, customer_id,
               prng_seed, prng_table, reg_map }
    }

    // Xorshift-32 key table — identical algorithm runs in generated Lua at runtime
    fn build_xorshift_table(seed: u32) -> Vec<u8> {
        let mut table = Vec::with_capacity(256);
        let mut s = seed;
        for _ in 0..256 {
            s ^= s.wrapping_shl(13);
            s ^= s.wrapping_shr(17);
            s ^= s.wrapping_shl(5);
            table.push((s & 0xFF) as u8);
        }
        table
    }

    fn shuffle_u8(v: &mut Vec<u8>, rng: &mut rand::rngs::ThreadRng) {
        for i in (1..v.len()).rev() {
            let j = rng.gen_range(0..=i);
            v.swap(i, j);
        }
    }

    // Emit a number as a random Luau literal: hex / binary-with-underscores / decimal
    fn fmt_num(n: u64, rng: &mut rand::rngs::ThreadRng) -> String {
        match rng.gen_range(0u8..9) {
            0 => format!("0x{:X}", n),
            1 => format!("0X{:x}", n),
            2 => {
                // Binary with __ separator
                let v = (n & 0xFFFF) as u32;
                if v == 0 { return "0".to_string(); }
                let bits = format!("{:b}", v);
                if bits.len() > 5 {
                    let mid = bits.len() - 4;
                    format!("0B{}__{}", &bits[..mid], &bits[mid..])
                } else {
                    format!("0B{}", bits)
                }
            }
            3 => {
                // Binary with single _ separator
                let v = (n & 0xFFFF) as u32;
                if v == 0 { return "0".to_string(); }
                let bits = format!("{:b}", v);
                if bits.len() > 5 {
                    let mid = bits.len() - 4;
                    format!("0b{}_{}", &bits[..mid], &bits[mid..])
                } else {
                    format!("0b{}", bits)
                }
            }
            4 => format!("0x{:04X}", n & 0xFFFF),
            5 => format!("0X{:04x}", n & 0xFFFF),
            6 => {
                // Byte as split binary nibbles: 0B0101_1010
                let v = n & 0xFF;
                format!("0B{:04b}_{:04b}", (v >> 4) & 0xF, v & 0xF)
            }
            7 => {
                let v = n & 0xFF;
                format!("0B{:08b}", v)
            }
            _ => format!("{}", n),
        }
    }

    fn serialize_proto(&self, func: &BytecodeFunction, out: &mut Vec<u8>) {
        out.extend_from_slice(&(func.instructions.len() as u32).to_le_bytes());
        out.extend_from_slice(&(func.protos.len() as u32).to_le_bytes());
        out.extend_from_slice(&(func.upvalues.len() as u32).to_le_bytes());
        for uv in &func.upvalues {
            match uv {
                UpvalSource::ParentLocal(i) => { out.push(0); out.extend_from_slice(&(*i as u32).to_le_bytes()); }
                UpvalSource::ParentUpval(i) => { out.push(1); out.extend_from_slice(&(*i as u32).to_le_bytes()); }
            }
        }
        for inst in &func.instructions {
            let physical_op = self.op_map[inst.op as usize];
            let remapped = crate::bytecode::Instruction::new(physical_op, inst.a, inst.b, inst.c);
            out.extend_from_slice(&remapped.to_bytes());
        }
        for proto in &func.protos { self.serialize_proto(proto, out); }
    }

    fn encrypt_str_const(&self, s: &str) -> Vec<u8> {
        // PRNG-based encryption using xorshift table — much stronger than linear XOR
        s.bytes().enumerate().map(|(i, b)| b ^ self.prng_table[i % 256]).collect()
    }

    fn gen_name(&mut self) -> String {
        // Extended confusable charset: I l O o Q 0 1 q _ and uppercase variants
        let starts: &[char] = &['I', 'l', 'O', '_', 'Q', 'I'];
        let chars: &[char]  = &['I', 'l', '1', 'I', '0', 'O', 'Q', 'q', 'o', 'O', '_', 'l', 'I', 'Q', '0'];
        let len = self.rng.gen_range(10..18usize);
        let mut name = String::with_capacity(len + 2);
        name.push('_');
        name.push(starts[self.rng.gen_range(0..starts.len())]);
        for _ in 0..len {
            name.push(chars[self.rng.gen_range(0..chars.len())]);
        }
        name
    }

    fn str_char_enc(&self, s: &str) -> String {
        let bytes: Vec<String> = s.bytes().map(|b| b.to_string()).collect();
        format!("string.char({})", bytes.join(","))
    }

    fn chunk_bytecode(&mut self, bytes: &[u8]) -> String {
        let num_chunks = self.rng.gen_range(14..24usize);
        let mut chunks = Vec::new();
        let mut pos = 0;
        for c in 0..num_chunks {
            let remaining = bytes.len().saturating_sub(pos);
            if remaining == 0 { break; }
            let size = if c == num_chunks - 1 {
                remaining
            } else {
                (remaining / (num_chunks - c).max(1) + self.rng.gen_range(0..8)).min(remaining).max(1)
            };
            let chunk = &bytes[pos..pos + size];
            let s: String = chunk.iter().map(|b| format!("\\{:03}", b)).collect();
            let wrap = match self.rng.gen_range(0u8..4) {
                0 => {
                    let v = self.gen_name();
                    format!("(function() local {} = \"{}\"; return {} end)()", v, s, v)
                }
                1 => {
                    let v = self.gen_name(); let w = self.gen_name();
                    format!("(function() local {}=\"{}\"; local {}={} return {} end)()", v, s, w, v, w)
                }
                _ => format!("\"{}\"", s),
            };
            chunks.push(wrap);
            pos += size;
            if pos >= bytes.len() { break; }
        }
        chunks.join("..")
    }

    pub fn generate(&mut self, func: &BytecodeFunction, build_id: &str) -> String {
        // ── Variable names (all obfuscated) ───────────────────────────────────
        let vm_name      = format!("_NPV5_{}", self.vm_id);
        let rm_name      = self.gen_name();   // physical register map
        let consts_name  = self.gen_name();
        let op_tbl       = self.gen_name();
        let layer1_name  = self.gen_name();
        let layer2_name  = self.gen_name();
        let layer3_name  = self.gen_name();
        let wm_name      = self.gen_name();
        let call_fn      = self.gen_name();
        let load_fn      = self.gen_name();
        let protos_name  = self.gen_name();
        let globals_name = self.gen_name();
        let sdec_name    = self.gen_name();
        let stbl_name    = self.gen_name();
        let skey_name    = self.gen_name();   // xorshift PRNG key table
        let bc_name      = self.gen_name();
        let op_map_name  = self.gen_name();

        let sv_jmp       = self.gen_name();
        let sv_ret       = self.gen_name();
        let sv_vmclo     = self.gen_name();
        let sv_isglob    = self.gen_name();
        let sv_fn        = self.gen_name();
        let sv_tbl       = self.gen_name();
        let sv_call      = self.gen_name();
        let sv_get       = self.gen_name();
        let sv_set       = self.gen_name();
        let sv_kind      = self.gen_name();
        let sv_idx       = self.gen_name();
        let sv_iscnt     = self.gen_name();
        let sv_istart    = self.gen_name();
        let sv_upvals    = self.gen_name();
        let sv_children  = self.gen_name();
        let sv_name_key  = self.gen_name();

        // ── Bytecode serialise + 3-pass XOR encrypt ───────────────────────────
        let mut raw_bytes = Vec::new();
        self.serialize_proto(func, &mut raw_bytes);

        // Checksum computed on raw (unencrypted) bytes — verified in Lua after decryption
        let checksum: u32 = raw_bytes.iter().enumerate()
            .fold(0u32, |acc, (i, &b)| {
                acc.wrapping_add((b as u32).wrapping_mul(((i % 251) as u32).wrapping_add(1)))
            });

        let enc1 = crate::encrypt::xor_encrypt(&raw_bytes, self.layer_keys[0]);
        let enc2 = crate::encrypt::xor_encrypt(&enc1,      self.layer_keys[1]);
        let enc3 = crate::encrypt::xor_encrypt(&enc2,      self.layer_keys[2]);
        let chunked = self.chunk_bytecode(&enc3);

        let k0 = self.layer_keys[0];
        let k1 = self.layer_keys[1];
        let k2 = self.layer_keys[2];
        let wm_low    = (self.watermark & 0xFFFFFFFF) as u32;
        let op_map_str = self.op_map.iter().map(|v| v.to_string()).collect::<Vec<_>>().join(",");
        let prng_seed  = self.prng_seed;

        // ── Physical register map (each entry randomly formatted) ─────────────
        let rm_entries: Vec<String> = self.reg_map.iter()
            .map(|&v| Self::fmt_num(v as u64, &mut self.rng))
            .collect();
        let reg_map_str: String = rm_entries.chunks(16)
            .map(|row| format!("    {}", row.join(",")))
            .collect::<Vec<_>>()
            .join(",\n");

        // ── Constants blob ─────────────────────────────────────────────────────
        let mut const_blob = String::new();
        self.serialize_consts_lua(func, &mut const_blob, &sdec_name, &consts_name);

        // ── Dispatch handlers ─────────────────────────────────────────────────
        let handlers = self.generate_handlers(
            &rm_name, &globals_name,
            &sv_jmp, &sv_ret, &sv_vmclo, &sv_isglob,
            &sv_fn, &sv_tbl, &sv_call, &sv_get, &sv_set,
            &sv_kind, &sv_idx,
            &sv_upvals, &sv_children, &sv_name_key,
        );
        let mut handler_str = String::new();
        for (phys_op, body) in &handlers {
            handler_str.push_str(&format!("  {}[{}]={}\n", op_tbl, phys_op, body));
        }

        // ── Misc random constants (formatted for visual diversity) ────────────
        let nv1 = self.gen_name(); let nv2 = self.gen_name(); let nv3 = self.gen_name();
        let nx1: u32 = self.rng.gen();
        let nx2: u32 = self.rng.gen();
        let seed_noise: u32 = self.rng.gen_range(1000..99999);

        let k0f   = Self::fmt_num(k0 as u64, &mut self.rng);
        let k1f   = Self::fmt_num(k1 as u64, &mut self.rng);
        let k2f   = Self::fmt_num(k2 as u64, &mut self.rng);
        let chkf  = Self::fmt_num(checksum as u64, &mut self.rng);
        let nx1f  = Self::fmt_num(nx1 as u64, &mut self.rng);
        let nx2f  = Self::fmt_num(nx2 as u64, &mut self.rng);
        let prngsf= Self::fmt_num(prng_seed as u64, &mut self.rng);
        let ff_f  = Self::fmt_num(0xFF, &mut self.rng);
        let ffff_f= Self::fmt_num(0xFFFF, &mut self.rng);
        let fff_f = Self::fmt_num(0xFFFFFFFF, &mut self.rng);
        let n251_f= Self::fmt_num(251, &mut self.rng);
        let n256_f= Self::fmt_num(256, &mut self.rng);
        let n255_f= Self::fmt_num(255, &mut self.rng);
        let n13_f = Self::fmt_num(13, &mut self.rng);
        let n17_f = Self::fmt_num(17, &mut self.rng);
        let n5_f  = Self::fmt_num(5, &mut self.rng);
        let wml_f = Self::fmt_num(wm_low as u64, &mut self.rng);

        // String-key initialisers (char-code encoded, no rawget)
        let sv_jmp_init      = self.str_char_enc("jmp");
        let sv_ret_init      = self.str_char_enc("return");
        let sv_vmclo_init    = self.str_char_enc("__vmclosure");
        let sv_isglob_init   = self.str_char_enc("__isglobal");
        let sv_fn_init       = self.str_char_enc("function");
        let sv_tbl_init      = self.str_char_enc("table");
        let sv_call_init     = self.str_char_enc("call");
        let sv_get_init      = self.str_char_enc("get");
        let sv_set_init      = self.str_char_enc("set");
        let sv_kind_init     = self.str_char_enc("kind");
        let sv_idx_init      = self.str_char_enc("idx");
        let sv_iscnt_init    = self.str_char_enc("instr_count");
        let sv_istart_init   = self.str_char_enc("instr_start");
        let sv_upvals_init   = self.str_char_enc("upvalues");
        let sv_children_init = self.str_char_enc("children");
        let sv_name_init     = self.str_char_enc("name");

        // ── Assemble output ────────────────────────────────────────────────────
        let mut out = String::with_capacity(65536);

        out += &format!("local {vm_name} = (function()\n");
        out += &format!("  -- NPv5 VM | Build:{build_id} | VM:{} | Cust:{}\n",
            self.vm_id, self.customer_id);

        // Noise locals
        out += &format!("  local {nv1} = bit32.bxor({nx1f},{nx2f})\n");
        out += &format!("  local {nv2} = {seed_noise}\n");
        out += &format!("  local {nv3} = bit32.band({nv1},{ffff_f})\n");
        let _ = (&nv2,); // suppress unused warning — nv2 is noise

        // String sentinel constants (char-code encoded, no rawget, no string literals)
        for (var, init) in &[
            (&sv_jmp,&sv_jmp_init),(&sv_ret,&sv_ret_init),(&sv_vmclo,&sv_vmclo_init),
            (&sv_isglob,&sv_isglob_init),(&sv_fn,&sv_fn_init),(&sv_tbl,&sv_tbl_init),
            (&sv_call,&sv_call_init),(&sv_get,&sv_get_init),(&sv_set,&sv_set_init),
            (&sv_kind,&sv_kind_init),(&sv_idx,&sv_idx_init),(&sv_iscnt,&sv_iscnt_init),
            (&sv_istart,&sv_istart_init),(&sv_upvals,&sv_upvals_init),
            (&sv_children,&sv_children_init),(&sv_name_key,&sv_name_init),
        ] { out += &format!("  local {var} = {init}\n"); }

        // Watermark integrity check
        out += &format!("  local {wm_name} = function()\n");
        out += &format!("    if bit32.band({wm_low},{fff_f}) ~= {wml_f} then repeat until false end\n");
        out += &format!("    if bit32.bxor({nv3},{nv3}) ~= 0 then repeat until false end\n");
        out += "  end\n";
        out += &format!("  {wm_name}()\n");

        // ── PRNG string key table — xorshift-32, matches Rust build_xorshift_table ──
        let sk_tmp = self.gen_name(); let sk_i = self.gen_name();
        out += &format!("  local {skey_name} = {{}}\n");
        out += "  do\n";
        out += &format!("    local {sk_tmp} = {prngsf}\n");
        out += &format!("    for {sk_i} = 0, {n255_f} do\n");
        // s ^= s<<13  (masked to 32 bits first to avoid Lua float imprecision)
        out += &format!("      {sk_tmp} = bit32.bxor({sk_tmp},bit32.lshift(bit32.band({sk_tmp},{fff_f}),{n13_f}))\n");
        out += &format!("      {sk_tmp} = bit32.bxor({sk_tmp},bit32.rshift({sk_tmp},{n17_f}))\n");
        out += &format!("      {sk_tmp} = bit32.bxor({sk_tmp},bit32.lshift(bit32.band({sk_tmp},{fff_f}),{n5_f}))\n");
        out += &format!("      {sk_tmp} = bit32.band({sk_tmp},{fff_f})\n");
        out += &format!("      {skey_name}[{sk_i}] = bit32.band({sk_tmp},{ff_f})\n");
        out += "    end\n  end\n";

        // ── String decrypt function (PRNG-keyed, cached) ───────────────────────
        let sd_e = self.gen_name(); let sd_t = self.gen_name();
        let sd_i = self.gen_name(); let sd_r = self.gen_name();
        out += &format!("  local {stbl_name} = {{}}\n");
        out += &format!("  local {sdec_name} = function({sd_e})\n");
        out += &format!("    if {stbl_name}[{sd_e}] then return {stbl_name}[{sd_e}] end\n");
        out += &format!("    local {sd_t} = {{}}\n");
        out += &format!("    for {sd_i} = 1, #{sd_e} do\n");
        out += &format!("      {sd_t}[{sd_i}] = string.char(bit32.bxor({sd_e}[{sd_i}],{skey_name}[(({sd_i}-1) % {n256_f})]))\n");
        out += "    end\n";
        out += &format!("    local {sd_r} = table.concat({sd_t})\n");
        out += &format!("    {stbl_name}[{sd_e}] = {sd_r}\n");
        out += &format!("    return {sd_r}\n  end\n");

        // ── Physical register map (all entries hex/binary formatted) ───────────
        out += &format!("  local {rm_name} = {{\n{reg_map_str}\n  }}\n");

        // ── Constants ─────────────────────────────────────────────────────────
        out += &format!("  local {consts_name} = {{}}\n");
        out += &const_blob;

        // ── Globals proxy ─────────────────────────────────────────────────────
        out += &format!("  local {globals_name} = setmetatable({{}},{{__index=function(_,k) return _G[k] end}})\n");

        // ── Bytecode blob + 3-pass XOR decryption ─────────────────────────────
        let bi = self.gen_name();
        out += &format!("  local {layer3_name} = {chunked}\n");
        out += &format!("  local {layer2_name} = {{}}\n");
        out += &format!("  for {bi} = 1, #{layer3_name} do\n");
        out += &format!("    {layer2_name}[{bi}] = bit32.bxor(string.byte({layer3_name},{bi}),bit32.band({k2f}+({bi}-1),{ff_f}))\n");
        out += "  end\n";
        out += &format!("  local {layer1_name} = {{}}\n");
        out += &format!("  for {bi} = 1, #{layer2_name} do\n");
        out += &format!("    {layer1_name}[{bi}] = bit32.bxor({layer2_name}[{bi}],bit32.band({k1f}+({bi}-1),{ff_f}))\n");
        out += "  end\n";
        out += &format!("  local {bc_name} = {{}}\n");
        out += &format!("  for {bi} = 1, #{layer1_name} do\n");
        out += &format!("    {bc_name}[{bi}] = bit32.bxor({layer1_name}[{bi}],bit32.band({k0f}+({bi}-1),{ff_f}))\n");
        out += "  end\n";

        // ── Bytecode integrity checksum ────────────────────────────────────────
        let chk_v = self.gen_name(); let chk_i = self.gen_name();
        out += "  do\n";
        out += &format!("    local {chk_v} = 0\n");
        out += &format!("    for {chk_i} = 1, #{bc_name} do\n");
        out += &format!("      {chk_v} = bit32.band({chk_v}+{bc_name}[{chk_i}]*(({chk_i} % {n251_f})+1),{fff_f})\n");
        out += "    end\n";
        out += &format!("    if {chk_v} ~= {chkf} then repeat until false end\n");
        out += "  end\n";

        // ── Opcode dispatch table ─────────────────────────────────────────────
        out += &format!("  local {op_map_name} = {{{op_map_str}}}\n");
        let _ = op_map_name; // embedded in bytecode ordering, not needed at runtime
        out += &format!("  local {op_tbl} = {{}}\n");
        out += &handler_str;

        // ── Bytecode pointer + u32/u8 readers ────────────────────────────────
        let bp = self.gen_name(); let u32fn = self.gen_name(); let u8fn = self.gen_name();
        out += &format!("  local {bp} = 1\n");
        out += &format!("  local function {u32fn}()\n");
        out += &format!("    local a,b,c,d={bc_name}[{bp}],{bc_name}[{bp}+1],{bc_name}[{bp}+2],{bc_name}[{bp}+3]\n");
        out += &format!("    {bp}={bp}+4\n");
        out += "    return a+b*256+c*65536+d*16777216\n  end\n";
        out += &format!("  local function {u8fn}()\n");
        out += &format!("    local b={bc_name}[{bp}]; {bp}={bp}+1; return b\n  end\n");

        // ── Proto loader ──────────────────────────────────────────────────────
        out += &format!("  local {protos_name} = {{}}\n");
        out += &format!("  local function {load_fn}()\n");
        out += &format!("    local idx=#{protos_name}+1\n");
        out += &format!("    local p={{[{sv_upvals}]={{}},[{sv_children}]={{}}}}\n");
        out += &format!("    {protos_name}[idx]=p\n");
        out += &format!("    p[{sv_iscnt}]={u32fn}()\n");
        out += &format!("    local nc={u32fn}()\n");
        out += &format!("    local nuv={u8fn}()\n");
        out += "    for _=1,nuv do\n";
        out += &format!("      local k={u8fn}()\n");
        out += &format!("      local i={u32fn}()\n");
        out += &format!("      table.insert(p[{sv_upvals}],{{[{sv_kind}]=k,[{sv_idx}]=i}})\n");
        out += "    end\n";
        out += &format!("    p[{sv_istart}]={bp}\n");
        out += &format!("    {bp}={bp}+p[{sv_iscnt}]*8\n");
        out += &format!("    for _=1,nc do table.insert(p[{sv_children}],{load_fn}()) end\n");
        out += "    return idx\n  end\n";
        out += &format!("  {load_fn}()\n");

        // ── Call / execution engine ───────────────────────────────────────────
        out += &format!("  local function {call_fn}(pi,args,upvals)\n");
        out += &format!("    local proto={protos_name}[pi]\n");
        out += "    local R={}\n";
        out += &format!("    for i=1,#args do R[{rm_name}[i]]=args[i] end\n");
        out += &format!("    local pc=proto[{sv_istart}]\n");
        out += &format!("    local lpc=proto[{sv_istart}]+proto[{sv_iscnt}]*8-1\n");
        out += "    while pc<=lpc do\n";
        out += "      local ipc=pc\n";
        out += &format!("      local o={bc_name}[pc]\n");
        out += &format!("      local a={bc_name}[pc+2]+{bc_name}[pc+3]*256\n");
        out += &format!("      local bh={bc_name}[pc+4]+{bc_name}[pc+5]*256\n");
        out += &format!("      local ch={bc_name}[pc+6]+{bc_name}[pc+7]*256\n");
        out += "      pc=pc+8\n";
        out += &format!("      local h={op_tbl}[o]\n");
        out += "      if h then\n";
        out += &format!("        local ctl,nv=h(R,a,bh,ch,proto,upvals,{call_fn},{protos_name},{consts_name})\n");
        out += &format!("        if ctl=={sv_jmp} then\n");
        out += "          pc=ipc+nv*8\n";
        out += &format!("        elseif ctl=={sv_ret} then\n");
        out += "          return nv\n";
        out += "        end\n      end\n    end\n    return nil\n  end\n";

        out += &format!("  return {call_fn}(1,{{}},{{}})\n");
        out += "end)()\n";
        out
    }

    fn serialize_consts_lua(&self, func: &BytecodeFunction, out: &mut String, sdec: &str, consts: &str) {
        self.serialize_consts_recursive(func, out, sdec, consts);
    }

    fn serialize_consts_recursive(&self, func: &BytecodeFunction, out: &mut String, sdec: &str, consts: &str) {
        for c in &func.constants {
            let lit = self.emit_const(c, sdec);
            out.push_str(&format!("  table.insert({consts}, {lit})\n"));
        }
        for proto in &func.protos { self.serialize_consts_recursive(proto, out, sdec, consts); }
    }

    fn emit_const(&self, c: &Constant, sdec: &str) -> String {
        match c.ctype.as_str() {
            "string" => {
                let raw = c.value.trim_matches('"');
                let enc = self.encrypt_str_const(raw);
                let bytes_lua = enc.iter().map(|b| b.to_string()).collect::<Vec<_>>().join(",");
                format!("{sdec}({{{bytes_lua}}})")
            }
            "number" => {
                if let Ok(n) = c.value.parse::<f64>() {
                    let salt  = (self.vm_id as i64).wrapping_mul(0x1337) & 0xFFFF;
                    let salt2 = (self.customer_id as i64).wrapping_mul(0xDEAD) & 0xFFFF;
                    format!("((({}) + {salt} + {salt2}) - {salt} - {salt2})", n as i64)
                } else { c.value.clone() }
            }
            "bool"   => if c.value == "true" { "true" } else { "false" }.to_string(),
            "nil"    => "nil".to_string(),
            "global" => {
                let name = c.value.trim_matches('"');
                let enc  = self.encrypt_str_const(name);
                let bytes_lua = enc.iter().map(|b| b.to_string()).collect::<Vec<_>>().join(",");
                format!("{{__isglobal=true,name={sdec}({{{bytes_lua}}})}}")
            }
            _ => "nil".to_string(),
        }
    }

    fn generate_handlers(&mut self,
        rm: &str, globals: &str,
        sv_jmp: &str, sv_ret: &str, sv_vmclo: &str, sv_isglob: &str,
        sv_fn: &str, sv_tbl: &str, sv_call: &str, sv_get: &str, sv_set: &str,
        sv_kind: &str, sv_idx: &str,
        sv_upvals: &str, sv_children: &str, sv_name: &str,
    ) -> Vec<(u8, String)> {
        let op_map = self.op_map.clone();
        // All register accesses go through the physical map (rm)
        // rm is a captured upvalue — handlers are closures
        let ra = format!("R[{rm}[a+1]]");
        let rb = format!("R[{rm}[b+1]]");
        let rc = format!("R[{rm}[c+1]]");

        let bodies: Vec<(u8, String)> = vec![
            (OpCode::LoadK as u8, format!(
                "function(R,a,b,c,_,_2,_3,_4,consts)\n    local k=consts[bit32.bor(b*256,c)+1]\n    if type(k)=={sv_tbl} and k[{sv_isglob}] then {ra}={globals}[k[{sv_name}]]\n    else {ra}=k end\n  end"
            )),
            (OpCode::Move as u8,    format!("function(R,a,b) {ra}={rb} end")),
            (OpCode::Add as u8,     format!("function(R,a,b,c) {ra}={rb}+{rc} end")),
            (OpCode::Sub as u8,     format!("function(R,a,b,c) {ra}={rb}-{rc} end")),
            (OpCode::Mul as u8,     format!("function(R,a,b,c) {ra}={rb}*{rc} end")),
            (OpCode::Div as u8,     format!("function(R,a,b,c) local d={rc}; if d==0 then d=1e-300 end; {ra}={rb}/d end")),
            (OpCode::Mod as u8,     format!("function(R,a,b,c) {ra}={rb}%{rc} end")),
            (OpCode::Pow as u8,     format!("function(R,a,b,c) {ra}={rb}^{rc} end")),
            (OpCode::Unm as u8,     format!("function(R,a,b) {ra}=-{rb} end")),
            (OpCode::Not as u8,     format!("function(R,a,b) {ra}=not {rb} end")),
            (OpCode::Len as u8,     format!("function(R,a,b) {ra}=#{rb} end")),
            (OpCode::Concat as u8,  format!("function(R,a,b,c) {ra}=tostring({rb})..tostring({rc}) end")),
            (OpCode::Eq as u8,      format!("function(R,a,b,c) {ra}=({rb}=={rc}) end")),
            (OpCode::Lt as u8,      format!("function(R,a,b,c) {ra}=({rb}<{rc}) end")),
            (OpCode::Le as u8,      format!("function(R,a,b,c) {ra}=({rb}<={rc}) end")),
            (OpCode::Ne as u8,      format!("function(R,a,b,c) {ra}=({rb}~={rc}) end")),
            (OpCode::Jmp as u8, format!(
                "function(R,a,b,c) local bits=b*65536+c; if bits>=2147483648 then bits=bits-4294967296 end; return {sv_jmp},bits end"
            )),
            (OpCode::LoadBool as u8, format!("function(R,a,b) {ra}=(b~=0) end")),
            (OpCode::LoadNil as u8,  format!("function(R,a) {ra}=nil end")),
            (OpCode::NewTable as u8, format!("function(R,a) {ra}={{}} end")),
            (OpCode::GetTable as u8, format!("function(R,a,b,c) {ra}={rb}[{rc}] end")),
            (OpCode::SetTable as u8, format!("function(R,a,b,c) {ra}[{rb}]={rc} end")),
            (OpCode::Call as u8, format!(
r#"function(R,a,b,c)
    local f={ra}; local args={{}}
    for i=1,b-1 do args[i]=R[{rm}[a+i+1]] end
    if type(f)=={sv_fn} then
      local rv={{f(table.unpack and table.unpack(args) or unpack(args))}}
      for i=1,#rv do R[{rm}[a+i]]=rv[i] end
    elseif type(f)=={sv_tbl} and f[{sv_vmclo}] then
      local rv=f[{sv_call}](args)
      if rv~=nil then {ra}=rv end
    end
  end"#)),
            (OpCode::Return as u8, format!(
r#"function(R,a,b)
    if b<=1 then return {sv_ret},nil end
    local rv={{}}
    for i=0,b-2 do rv[i+1]=R[{rm}[a+i+1]] end
    return {sv_ret},#rv==1 and rv[1] or rv
  end"#)),
            (OpCode::Closure as u8, format!(
r#"function(R,a,b,c,proto,upvals,callfn,protos)
    local pi=bit32.bor(b*256,c)+1
    local child=protos[pi]
    if not child then {ra}=nil; return end
    local captured={{}}
    for i,uv in ipairs(child[{sv_upvals}]) do
      if uv[{sv_kind}]==0 then
        local ri={rm}[uv[{sv_idx}]+1]
        captured[i]={{[{sv_get}]=function() return R[ri] end,[{sv_set}]=function(v) R[ri]=v end}}
      else
        captured[i]=upvals[uv[{sv_idx}]+1] or {{[{sv_get}]=function() return nil end,[{sv_set}]=function() end}}
      end
    end
    {ra}={{[{sv_vmclo}]=true,[{sv_call}]=function(args) return callfn(pi,args,captured) end}}
  end"#)),
            (OpCode::GetUpval as u8, format!(
                "function(R,a,b,c,proto,upvals) local uv=upvals[b+1]; {ra}=(uv and uv[{sv_get}] and uv[{sv_get}]() or nil) end"
            )),
            (OpCode::SetUpval as u8, format!(
                "function(R,a,b,c,proto,upvals) local uv=upvals[b+1]; if uv and uv[{sv_set}] then uv[{sv_set}]({ra}) end end"
            )),
            (OpCode::Band as u8,    format!("function(R,a,b,c) {ra}=bit32.band({rb},{rc}) end")),
            (OpCode::Bor as u8,     format!("function(R,a,b,c) {ra}=bit32.bor({rb},{rc}) end")),
            (OpCode::Bxor as u8,    format!("function(R,a,b,c) {ra}=bit32.bxor({rb},{rc}) end")),
            (OpCode::ToNum as u8,   format!("function(R,a,b) {ra}=tonumber({rb}) or 0 end")),
            (OpCode::ToStr as u8,   format!("function(R,a,b) {ra}=tostring({rb}) end")),
            (OpCode::TestJmp as u8, format!(
                "function(R,a,b,c) if not {ra} then local bits=b*65536+c; if bits>=2147483648 then bits=bits-4294967296 end; return {sv_jmp},bits end end"
            )),
        ];

        // sv_children unused in handlers (used in loader) — silence warning
        let _ = sv_children;

        bodies.into_iter().map(|(logical_op, body)| {
            let physical_op = op_map[logical_op as usize];
            (physical_op, body)
        }).collect()
    }
}
