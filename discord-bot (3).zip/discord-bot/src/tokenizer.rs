use std::iter::Peekable;
use std::str::Chars;

#[derive(Debug, Clone, PartialEq)]
pub enum TokenType {
    Number, String, Ident, Keyword, Symbol, Eof, Comment,
}

#[derive(Debug, Clone)]
pub struct Token {
    pub ty: TokenType,
    pub val: String,
    pub line: usize,
}

pub struct LuaTokenizer<'a> {
    input: Peekable<Chars<'a>>,
    line: usize,
}

impl<'a> LuaTokenizer<'a> {
    pub fn new(code: &'a str) -> Self {
        Self { input: code.chars().peekable(), line: 1 }
    }

    pub fn tokenize(&mut self) -> Vec<Token> {
        let mut tokens = Vec::new();
        while let Some(t) = self.next_token() {
            if t.ty == TokenType::Eof { tokens.push(t); break; }
            if t.ty == TokenType::Comment { continue; }
            tokens.push(t);
        }
        tokens
    }

    fn next_token(&mut self) -> Option<Token> {
        self.skip_whitespace();
        let line = self.line;
        let ch = match self.peek() {
            Some(c) => c,
            None => return Some(Token { ty: TokenType::Eof, val: String::new(), line }),
        };
        if ch == '-' && self.peek_nth(1) == Some('-') {
            self.advance(); self.advance();
            if self.peek_nth(0) == Some('[') && self.peek_nth(1) == Some('[') {
                self.advance(); self.advance();
                while !(self.peek() == Some(']') && self.peek_nth(1) == Some(']')) {
                    if self.peek().is_none() { break; }
                    self.advance();
                }
                self.advance(); self.advance();
            } else {
                while self.peek().map(|c| c != '\n').unwrap_or(false) { self.advance(); }
            }
            return self.next_token();
        }
        if ch == '[' && self.peek_nth(1) == Some('[') {
            return Some(self.read_long_string(line));
        }
        if ch == '"' || ch == '\'' {
            return Some(self.read_string(line, ch));
        }
        if ch.is_ascii_digit() {
            return Some(Token { ty: TokenType::Number, val: self.read_number(), line });
        }
        if ch.is_alphabetic() || ch == '_' {
            let word = self.read_ident();
            let ty = if is_keyword(&word) { TokenType::Keyword } else { TokenType::Ident };
            return Some(Token { ty, val: word, line });
        }
        let sym = self.read_symbol();
        Some(Token { ty: TokenType::Symbol, val: sym, line })
    }

    fn peek(&mut self) -> Option<char> { self.input.peek().copied() }
    fn peek_nth(&mut self, n: usize) -> Option<char> {
        self.input.clone().nth(n)
    }
    fn advance(&mut self) -> Option<char> {
        let c = self.input.next();
        if c == Some('\n') { self.line += 1; }
        c
    }

    fn skip_whitespace(&mut self) {
        while let Some(c) = self.peek() {
            if c.is_ascii_whitespace() { self.advance(); } else { break; }
        }
    }

    fn read_string(&mut self, line: usize, quote: char) -> Token {
        self.advance();
        let mut val = String::new();
        val.push(quote);
        while let Some(c) = self.peek() {
            if c == quote { self.advance(); val.push(quote); break; }
            if c == '\\' {
                self.advance();
                if let Some(esc) = self.advance() {
                    val.push('\\'); val.push(esc);
                }
            } else {
                val.push(self.advance().unwrap());
            }
        }
        Token { ty: TokenType::String, val, line }
    }

    fn read_long_string(&mut self, line: usize) -> Token {
        self.advance(); self.advance();
        let mut val = String::from("[[");
        while !(self.peek() == Some(']') && self.peek_nth(1) == Some(']')) {
            if let Some(c) = self.advance() { val.push(c); }
            else { break; }
        }
        if self.peek() == Some(']') && self.peek_nth(1) == Some(']') {
            self.advance(); self.advance();
            val.push(']'); val.push(']');
        }
        Token { ty: TokenType::String, val, line }
    }

    fn read_number(&mut self) -> String {
        let mut val = String::new();
        if self.peek() == Some('0') && self.peek_nth(1).map(|c| c == 'x' || c == 'X').unwrap_or(false) {
            val.push(self.advance().unwrap());
            val.push(self.advance().unwrap());
            while let Some(c) = self.peek() {
                if c.is_ascii_digit() || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F') {
                    val.push(self.advance().unwrap());
                } else { break; }
            }
        } else {
            while let Some(c) = self.peek() {
                if c.is_ascii_digit() || c == '.' { val.push(self.advance().unwrap()); }
                else { break; }
            }
            if let Some(c) = self.peek() {
                if c == 'e' || c == 'E' {
                    val.push(self.advance().unwrap());
                    if self.peek() == Some('+') || self.peek() == Some('-') {
                        val.push(self.advance().unwrap());
                    }
                    while let Some(c) = self.peek() {
                        if c.is_ascii_digit() { val.push(self.advance().unwrap()); }
                        else { break; }
                    }
                }
            }
        }
        val
    }

    fn read_ident(&mut self) -> String {
        let mut val = String::new();
        while let Some(c) = self.peek() {
            if c.is_alphanumeric() || c == '_' { val.push(self.advance().unwrap()); }
            else { break; }
        }
        val
    }

    fn read_symbol(&mut self) -> String {
        let syms = ["...", "..", "==", "~=", "<=", ">=", "::", "//", "<<", ">>",
                    "+", "-", "*", "/", "%", "^", "#", "<", ">", "=", ";", ":", ",",
                    ".", "(", ")", "[", "]", "{", "}", "\\"];
        for s in syms.iter() {
            let mut matched = true;
            for (i, ch) in s.chars().enumerate() {
                if self.peek_nth(i) != Some(ch) { matched = false; break; }
            }
            if matched {
                for _ in 0..s.len() { self.advance(); }
                return s.to_string();
            }
        }
        self.advance().unwrap().to_string()
    }
}

fn is_keyword(word: &str) -> bool {
    matches!(word, "and"|"break"|"do"|"else"|"elseif"|"end"|"false"|"for"|"function"|
             "goto"|"if"|"in"|"local"|"nil"|"not"|"or"|"repeat"|"return"|"then"|
             "true"|"until"|"while"|"continue")
}
