use rand::Rng;
use std::collections::HashSet;
use crate::cfg::CFGObfuscator;
use crate::watermark::Watermarker;
use crate::junk::JunkGenerator;
use crate::vm::VMGenerator;
use crate::tokenizer::LuaTokenizer;
use crate::parser::LuaParser;
use crate::bytecode::BytecodeCompiler;

const LUA_KEYWORDS: &[&str] = &[
    "and","break","do","else","elseif","end","false","for","function",
    "goto","if","in","local","nil","not","or","repeat","return","then",
    "true","until","while","continue"
];

const LUA_GLOBALS: &[&str] = &[
    "assert","collectgarbage","error","getfenv","getmetatable","ipairs",
    "load","loadstring","next","pairs","pcall","print","rawequal","rawget",
    "rawset","select","setfenv","setmetatable","tonumber","tostring","type",
    "unpack","xpcall","_G","_VERSION","game","workspace","script","require",
    "math","string","table","os","debug","bit32","coroutine","io",
    "Instance","Vector3","CFrame","Color3","UDim","UDim2","Ray","Random",
    "BrickColor","tick","wait","delay","spawn","task","GetService",
    "WaitForChild","FindFirstChild","Connect","Disconnect","Fire","Invoke",
    "Clone","Destroy","IsA","Name","Parent","Value","typeof","enum",
    "settings","stats","time","warn","setclipboard","writefile","readfile","delfile",
];

const EXPLOIT_APIS: &[&str] = &[
    "getgc","getgenv","getreg","getrenv","getrawmetatable","setrawmetatable",
    "hookfunction","hookmetamethod","newcclosure","checkcaller","islclosure",
    "dumpstring","decompile","saveinstance","getconnections","getconstants",
    "getproto","getprotos","getstack","getupvalues","setupvalue","getupvalue",
    "setconstant","getconstant","getinfo","sethook","getlocal","setlocal",
    "upvalueid","upvaluejoin","syn","krnl","Fluxus","ScriptWare",
    "Oxygen","Comet","Electron","Codex","Arceus","Trigon","VegaX","Hydrogen",
    "Delta","Macsploit","Exoliner","Novaline","Zorara","Synapse",
    "SirHurt","Sentinel","ProtoSmasher","Helios","Elysian","Seliware",
    "gethiddenproperty","sethiddenproperty","gethui","getinstances",
    "getnilinstances","getscripts","getmodules","Drawing","isrbxactive",
    "request","http_request","appendfile","mousemoverel","mousemoveabs",
    "mouse1click","mouse2click","keypress","keyrelease","getclipboard",
    "isexecutorclosure","closureType","clonefunction","getfunctionhash",
    "firetouchinterest","fireproximityprompt","firesignal",
    "getnamecallmethod","setnamecallmethod","queue_on_teleport",
    "cache_replace","cache_invalidate","compare_mt",
    "isscriptable","setscriptable","run_on_actor",
];

pub struct NothingProtectionV5 {
    pub level: String,
    pub seed: u64,
    pub preserve: HashSet<String>,
    pub build_id: String,
    pub vm_count: usize,
    pub rng: rand::rngs::ThreadRng,
    pub customer_id: u32,
}

impl NothingProtectionV5 {
    pub fn new(level: &str, seed: Option<u64>, preserve: Option<Vec<String>>) -> Self {
        let mut rng = rand::thread_rng();
        let s = seed.unwrap_or_else(|| rng.gen());
        let mut set: HashSet<String> = LUA_KEYWORDS.iter().chain(LUA_GLOBALS.iter())
            .map(|x| x.to_string()).collect();
        if let Some(p) = preserve { for name in p { set.insert(name); } }
        let build_id = format!("{:016x}", s);
        let customer_id: u32 = rng.gen();
        Self { level: level.to_string(), seed: s, preserve: set,
               build_id, vm_count: 0, rng, customer_id }
    }

    // ─── Protection layer breakdown (maximum, N layers) ───────────────────────
    //
    //  Layer type     Count   Description
    //  ─────────────  ──────  ────────────────────────────────────────────────────
    //  Watermark         1   ASCII-art comment at top of output file
    //  Source scramble   1   Junk variable/function lines injected between real code
    //  Bytecode VM       1   Custom register-VM with randomised opcode table +
    //                         3-pass XOR-encrypted bytecode + encrypted string pool
    //  XOR-b64 layers  N-1   Base64+XOR encryption, unique random key per layer,
    //                         alternating layers also CFG-wrapped
    //  CFG noise    ⌊N/2⌋   goto-dispatch or while-dispatch injected on inner layers
    //  Anti-exploit      1   49 exploit-API globals checked (inside encrypted blob)
    //  Roblox check      1   6 game-environment assertions (inside encrypted blob)
    //  Anti-decompiler   1   9 runtime traps: rotation checks, hash checks, timing
    //  Junk code         1   24 dead functions injected (inside encrypted blob)
    //  Build watermark   1   Runtime hash verification of build ID + customer ID
    //
    //  Total shells an attacker must peel (maximum, 7 layers):
    //    1 outer shell + 6 inner layers = 7 decrypt operations + 1 VM reverse
    //
    pub fn obfuscate(&mut self, code: &str, layers: usize) -> String {
        let layers = layers.clamp(1, 10);
        let build_id = self.build_id.clone();
        let customer_id = self.customer_id;
        let wm = Self::watermark();

        match self.level.as_str() {

            "basic" => {
                let inner = self.build_innermost_payload(code, false, false);
                format!("{}\n{}", wm, self.make_outer_shell(&inner))
            }

            "high" => {
                let n = layers.max(2);
                let inner = self.build_innermost_payload(code, false, false);
                let mut cur = self.make_inner_layer(&inner);
                for _ in 1..(n - 1) { cur = self.make_inner_layer(&cur); }
                format!("{}\n{}", wm, self.make_outer_shell(&cur))
            }

            "vm" => {
                let n = layers.max(2);
                let vm_lua = self.try_vm(code, customer_id, &build_id);
                // Second VM pass for high layer counts (stacked VM)
                let vm_lua2 = if layers >= 6 {
                    self.try_vm(&vm_lua, customer_id, &build_id)
                } else { vm_lua };
                let inner  = self.build_innermost_payload(&vm_lua2, false, false);
                let mut cur = self.make_inner_layer(&inner);
                for _ in 1..(n - 1) { cur = self.make_inner_layer(&cur); }
                format!("{}\n{}", wm, self.make_outer_shell(&cur))
            }

            // ── MAXIMUM ───────────────────────────────────────────────────────
            // Pipeline (innermost → outermost):
            //   source scramble → VM → innermost payload → N-1 inner layers
            //   (with CFG on alternates) → outer shell (no CFG, no visible API names)
            _ => {
                let enc_shells = (layers.max(2) - 1).max(1);

                // Pre-pass: scramble the source code with junk lines between real statements
                let scrambled = self.scramble_source(code);

                // Bytecode VM pass 1 (32 MB stack thread to avoid overflow on large scripts)
                let vm_lua = self.try_vm(&scrambled, customer_id, &build_id);

                // Bytecode VM pass 2 — stacked VM for layers >= 8 (2-layer VM protection)
                let vm_lua2 = if layers >= 8 {
                    self.try_vm(&vm_lua, customer_id, &build_id)
                } else {
                    vm_lua
                };

                // Everything sealed inside encrypted blob
                let inner = self.build_innermost_payload(&vm_lua2, true, true);

                // Stack enc_shells compact inner layers
                let mut cur = self.make_inner_layer(&inner);
                for i in 1..enc_shells {
                    if i % 2 == 0 && enc_shells > 3 {
                        let cfg_seed: u64 = self.rng.gen();
                        let mut cfg = CFGObfuscator::new(cfg_seed);
                        cur = cfg.wrap_with_dispatch_noise(&cur);
                    }
                    cur = self.make_inner_layer(&cur);
                }

                // Outermost shell — no visible API names, no recognisable patterns
                format!("{}\n{}", wm, self.make_outer_shell(&cur))
            }
        }
    }

    // ── Watermark ─────────────────────────────────────────────────────────────
    pub fn watermark() -> &'static str {
r#"--[[
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

███╗   ██╗ ██████╗ ████████╗██╗  ██╗██╗███╗   ██╗ ██████╗
████╗  ██║██╔═══██╗╚══██╔══╝██║  ██║██║████╗  ██║██╔════╝
██╔██╗ ██║██║   ██║   ██║   ███████║██║██╔██╗ ██║██║  ███╗
██║╚██╗██║██║   ██║   ██║   ██╔══██║██║██║╚██╗██║██║   ██║
██║ ╚████║╚██████╔╝   ██║   ██║  ██║██║██║ ╚████║╚██████╔╝
╚═╝  ╚═══╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝

              N o t h i n g   P r o t e c t i o n

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
]]"#
    }

    // ── VM pass — 32 MB stack thread avoids recursive-parser overflow ─────────
    fn try_vm(&mut self, code: &str, customer_id: u32, build_id: &str) -> String {
        let code_s  = code.to_string();
        let build_s = build_id.to_string();
        let vm_id   = self.vm_count;

        let result: Option<String> = std::thread::Builder::new()
            .stack_size(32 * 1024 * 1024)
            .spawn(move || -> Option<String> {
                let compiled = std::panic::catch_unwind(|| {
                    let tokens = LuaTokenizer::new(&code_s).tokenize();
                    let ast    = LuaParser::new(tokens).parse();
                    let mut c  = BytecodeCompiler::new(vec![]);
                    c.compile_function(&ast)
                });
                match compiled {
                    Ok(func) => {
                        let mut vg = VMGenerator::new(vm_id, customer_id);
                        Some(vg.generate(&func, &build_s))
                    }
                    Err(_) => None,
                }
            })
            .ok()
            .and_then(|h| h.join().ok())
            .flatten();

        match result {
            Some(lua) => { self.vm_count += 1; lua }
            None      => self.make_inner_layer(code),
        }
    }

    // ── Source scrambler — injects junk between real code lines ──────────────
    // Adds dead-code variable declarations at random positions between real
    // statements so the source is noisy before the VM sees it.
    fn scramble_source(&mut self, code: &str) -> String {
        let mut out   = String::with_capacity(code.len() * 2);
        let mut depth = 0i32;

        for line in code.lines() {
            let trimmed = line.trim();

            // Track nesting depth — only inject junk at top-level
            for word in trimmed.split_whitespace() {
                match word {
                    "do"|"then"|"function"|"repeat" => depth += 1,
                    "end"|"until"                   => depth -= 1,
                    _ => {}
                }
            }

            out.push_str(line);
            out.push('\n');

            if depth <= 0 && !trimmed.is_empty() && !trimmed.starts_with("--") {
                depth = 0; // clamp negative from unmatched end keywords
                if self.rng.gen_range(0..3u8) == 0 {
                    // Inline arithmetic junk: random dead local that the VM will see
                    // but the reader cannot easily distinguish from real state.
                    let n = self.gen_name();
                    let a: i64 = self.rng.gen_range(1..9999);
                    let b: i64 = self.rng.gen_range(1..999);
                    let expr = self.hide_const(a + b);
                    out.push_str(&format!("local {}={}\n", n, expr));
                }
            }
        }
        out
    }

    // ── Innermost payload: guards + junk + code (never readable) ─────────────
    fn build_innermost_payload(
        &mut self,
        code: &str,
        include_roblox: bool,
        include_watermark: bool,
    ) -> String {
        let guards   = self.env_detect_lua();
        let traps    = self.anti_decompiler_lua();
        let roblox   = if include_roblox { self.roblox_anti_cheat() } else { String::new() };
        let wm_lua   = if include_watermark {
            let bid = self.build_id.clone();
            let cid = self.customer_id;
            let mut wm = Watermarker::new(&bid, cid);
            wm.generate_lua_checks()
        } else { String::new() };
        let junk_n = match self.level.as_str() { "basic" => 6, "high" => 14, _ => 24 };
        let mut jg = JunkGenerator::new();
        let junk = jg.gen_library(junk_n);

        let mut parts = vec![guards, traps];
        if !roblox.is_empty()  { parts.push(roblox); }
        if !wm_lua.is_empty()  { parts.push(wm_lua); }
        parts.push(junk);
        parts.push(code.to_string());
        parts.join("\n")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // OUTER SHELL  (the ONLY code an attacker can see)
    //
    // Security properties vs. common 25 ms deobfuscators:
    //
    //  ✗ No "loadstring" string literal anywhere (encoded as char codes at runtime)
    //  ✗ No "pcall" string literal anywhere (same)
    //  ✗ No "bit32.bxor / bit32.lshift …" identifiers (local aliases only)
    //  ✗ No 64-element string.char list (b64 alphabet built from ranges at runtime)
    //  ✗ No two recognisable functions "decode + decrypt" (merged into one)
    //  ✗ Key is stored rotated; un-rotated at runtime → key never appears as-is
    //  ✓ All variable names are I/l/1/O/0/_ lookalikes
    //  ✓ Encrypted payload is split into N random-width string chunks
    //  ✓ Wrapped in a clean do…end — no goto labels outside
    // ─────────────────────────────────────────────────────────────────────────
    fn make_outer_shell(&mut self, code: &str) -> String {
        let key_len: usize = self.rng.gen_range(32..64);
        let key: Vec<u8>   = (0..key_len).map(|_| self.rng.gen::<u8>()).collect();
        let roll: u8       = self.rng.gen_range(1u8..254);

        let encrypted: Vec<u8> = code.bytes().enumerate().map(|(i, b)| {
            b ^ key[i % key_len] ^ roll.wrapping_add((i & 0xFF) as u8)
        }).collect();

        let b64 = b64_encode(&encrypted);

        // Chunked b64 — random widths defeat pattern matchers that look for "=" padding
        let chunk_n = self.rng.gen_range(30..60usize);
        let csz     = (b64.len() / chunk_n).max(4);
        let b64_expr: String = b64.as_bytes().chunks(csz)
            .map(|c| format!("\"{}\"", std::str::from_utf8(c).unwrap_or("")))
            .collect::<Vec<_>>()
            .join("..");

        // Key stored rotated; un-rotated at runtime
        let offset = self.rng.gen_range(1..key_len);
        let mut rot = key.clone(); rot.rotate_left(offset);
        let key_nums: String = rot.iter().map(|b| b.to_string()).collect::<Vec<_>>().join(",");
        let klen = self.hide_const(key_len as i64);

        // ── All variable names — lookalike charset ────────────────────────────
        // API aliases (string.byte, table.insert, bit32.bxor, …)
        let _sb  = self.gen_name(); // string.byte
        let _sc  = self.gen_name(); // string.char
        let _ti  = self.gen_name(); // table.insert
        let _tc  = self.gen_name(); // table.concat
        let _bx  = self.gen_name(); // bit32.bxor
        let _bl  = self.gen_name(); // bit32.lshift
        let _br  = self.gen_name(); // bit32.rshift
        let _bd  = self.gen_name(); // bit32.band
        let _bo  = self.gen_name(); // bit32.bor
        let _ls  = self.gen_name(); // loadstring (recovered at runtime)
        let _pc  = self.gen_name(); // pcall       (recovered at runtime)
        // Core variables
        let vky  = self.gen_name(); // key table
        let vrl  = self.gen_name(); // roll value
        let vi   = self.gen_name(); // loop index
        let vt   = self.gen_name(); // temp for key unrotation
        let va   = self.gen_name(); // b64 alphabet table
        let val  = self.gen_name(); // b64 alphabet string
        let vlu  = self.gen_name(); // b64 lookup table
        // exec function params / locals
        let vf   = self.gen_name(); // the combined decode+decrypt function
        let vps  = self.gen_name(); // input b64 string param
        let vkp  = self.gen_name(); // key param
        let vrp  = self.gen_name(); // roll param
        let vo   = self.gen_name(); // output table
        let vac  = self.gen_name(); // bit accumulator
        let vct  = self.gen_name(); // bit counter
        let vp   = self.gen_name(); // byte position
        let vkl  = self.gen_name(); // key length
        let vv   = self.gen_name(); // b64 value lookup
        let vb0  = self.gen_name(); // decoded byte 0
        let vb1  = self.gen_name(); // decoded byte 1
        let vb2  = self.gen_name(); // decoded byte 2
        let vtmp = self.gen_name(); // padding temp
        let vd   = self.gen_name(); // data string
        let vfn  = self.gen_name(); // loaded function
        let vok  = self.gen_name(); // pcall result

        // "loadstring" as char codes: 108 111 97 100 115 116 114 105 110 103
        let ls_chars = "108,111,97,100,115,116,114,105,110,103";
        // "load" as fallback: 108 111 97 100
        let ld_chars = "108,111,97,100";
        // "pcall" as char codes: 112 99 97 108 108
        let pc_chars = "112,99,97,108,108";

        // bit32 field names as char codes
        fn char_code_str(s: &str) -> String {
            s.bytes().map(|b| b.to_string()).collect::<Vec<_>>().join(",")
        }
        let bxor_chars = char_code_str("bxor");
        let blsh_chars = char_code_str("lshift");
        let brsh_chars = char_code_str("rshift");
        let band_chars = char_code_str("band");
        let borr_chars = char_code_str("bor");

        let sb_chars   = char_code_str("byte");
        let sc_chars   = char_code_str("char");
        let ti_chars   = char_code_str("insert");
        let tc_chars   = char_code_str("concat");

        // Extra locals for safe two-step lib aliasing (executor-compatible)
        let vstr = self.gen_name(); // local alias for 'string' lib
        let vtbl = self.gen_name(); // local alias for 'table' lib
        let vb32 = self.gen_name(); // local alias for 'bit32' lib
        let vglb = self.gen_name(); // local alias for '_G'

        let mut s = String::with_capacity(b64.len() + 4096);
        s += "do\n";

        // ── Runtime function resolution — no API name appears as a string ─────
        // Step 1: alias the stdlib tables to plain locals (works in all executors)
        // Step 2: index the alias — avoids both rawget() and (lib)[key] patterns
        s += &format!("local {vstr}=string\n");
        s += &format!("local {vtbl}=table\n");
        s += &format!("local {vb32}=bit32\n");
        s += &format!("local {vglb}=_G\n");
        s += &format!("local {_sc}={vstr}[string.char({sc_chars})]\n");
        s += &format!("local {_sb}={vstr}[string.char({sb_chars})]\n");
        s += &format!("local {_ti}={vtbl}[{_sc}({ti_chars})]\n");
        s += &format!("local {_tc}={vtbl}[{_sc}({tc_chars})]\n");
        s += &format!("local {_bx}={vb32}[{_sc}({bxor_chars})]\n");
        s += &format!("local {_bl}={vb32}[{_sc}({blsh_chars})]\n");
        s += &format!("local {_br}={vb32}[{_sc}({brsh_chars})]\n");
        s += &format!("local {_bd}={vb32}[{_sc}({band_chars})]\n");
        s += &format!("local {_bo}={vb32}[{_sc}({borr_chars})]\n");
        // loadstring / load — reconstructed at runtime via aliased _G
        s += &format!("local {_ls}={vglb}[{_sc}({ls_chars})] or {vglb}[{_sc}({ld_chars})]\n");
        // pcall — reconstructed at runtime
        s += &format!("local {_pc}={vglb}[{_sc}({pc_chars})]\n");

        // ── Rotated key table + runtime unrotation ────────────────────────────
        s += &format!("local {vky}={{{key_nums}}}\n");
        s += &format!("do local {vt}={{}} for {vi}=1,{klen} do {vt}[{vi}]={vky}[(({vi}+{offset}-1)%({klen}))+1] end {vky}={vt} end\n");
        s += &format!("local {vrl}={roll}\n");

        // ── b64 alphabet built from ranges (no 64-element list) ───────────────
        s += &format!("local {va}={{}}\n");
        s += &format!("for {vi}=65,90 do {_ti}({va},{_sc}({vi})) end\n");  // A-Z
        s += &format!("for {vi}=97,122 do {_ti}({va},{_sc}({vi})) end\n"); // a-z
        s += &format!("for {vi}=48,57 do {_ti}({va},{_sc}({vi})) end\n");  // 0-9
        s += &format!("{_ti}({va},{_sc}(43)) {_ti}({va},{_sc}(47))\n");    // + /
        s += &format!("local {val}={_tc}({va})\n");
        s += &format!("local {vlu}={{}}\n");
        s += &format!("for {vi}=1,64 do {vlu}[{_sb}({val},{vi})]={vi}-1 end\n");

        // ── Combined decode+decrypt in ONE function ────────────────────────────
        // (Breaking the two-function pattern that deobfuscators grep for)
        s += &format!("local function {vf}({vps},{vkp},{vrp})\n");
        s += &format!("local {vo},{vac},{vct},{vp},{vkl}={{}},0,0,0,#{vkp}\n");
        s += &format!("for {vi}=1,#{vps} do\n");
        s += &format!("local {vv}={vlu}[{_sb}({vps},{vi})]\n");
        s += &format!("if {vv} then\n");
        s += &format!("{vac}={_bo}({_bl}({vac},6),{vv})\n");
        s += &format!("{vct}={vct}+1\n");
        s += &format!("if {vct}==4 then\n");
        s += &format!("local {vb0}={_bd}({_br}({vac},16),255)\n");
        s += &format!("local {vb1}={_bd}({_br}({vac},8),255)\n");
        s += &format!("local {vb2}={_bd}({vac},255)\n");
        // XOR each decoded byte inline — single-pass, no separate function
        s += &format!("{vp}={vp}+1\n");
        s += &format!("{_ti}({vo},{_sc}({_bx}({vb0},{vkp}[(({vp}-1)%{vkl})+1],{_bd}({vrp}+({vp}-1),255))))\n");
        s += &format!("{vp}={vp}+1\n");
        s += &format!("{_ti}({vo},{_sc}({_bx}({vb1},{vkp}[(({vp}-1)%{vkl})+1],{_bd}({vrp}+({vp}-1),255))))\n");
        s += &format!("{vp}={vp}+1\n");
        s += &format!("{_ti}({vo},{_sc}({_bx}({vb2},{vkp}[(({vp}-1)%{vkl})+1],{_bd}({vrp}+({vp}-1),255))))\n");
        s += &format!("{vac}=0 {vct}=0\n");
        s += "end end end\n";
        // Padding handling (2 or 3 remaining b64 chars)
        s += &format!("if {vct}==3 then\n");
        s += &format!("local {vtmp}={_br}({vac},2)\n");
        s += &format!("{vp}={vp}+1; {_ti}({vo},{_sc}({_bx}({_bd}({_br}({vtmp},8),255),{vkp}[(({vp}-1)%{vkl})+1],{_bd}({vrp}+({vp}-1),255))))\n");
        s += &format!("{vp}={vp}+1; {_ti}({vo},{_sc}({_bx}({_bd}({vtmp},255),{vkp}[(({vp}-1)%{vkl})+1],{_bd}({vrp}+({vp}-1),255))))\n");
        s += &format!("elseif {vct}==2 then\n");
        s += &format!("{vp}={vp}+1; {_ti}({vo},{_sc}({_bx}({_bd}({_br}({vac},4),255),{vkp}[(({vp}-1)%{vkl})+1],{_bd}({vrp}+({vp}-1),255))))\n");
        s += "end\n";
        s += &format!("return {_tc}({vo})\nend\n");

        // ── Encrypted payload (chunked b64) ───────────────────────────────────
        s += &format!("local {vd}={b64_expr}\n");
        // Decode + run — no "loadstring" or "pcall" string anywhere
        s += &format!("local {vfn}={_ls}({vf}({vd},{vky},{vrl}))\n");
        s += &format!("if type({vfn})~=\"function\" then return end\n");
        s += &format!("local {vok}={_pc}({vfn})\n");

        s += "end\n";
        s
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INNER LAYER  (compact; encrypted by next outer layer — never visible)
    // ─────────────────────────────────────────────────────────────────────────
    fn make_inner_layer(&mut self, code: &str) -> String {
        let key_len: usize = self.rng.gen_range(24..48);
        let key: Vec<u8>   = (0..key_len).map(|_| self.rng.gen::<u8>()).collect();
        let roll: u8       = self.rng.gen_range(1u8..254);

        let encrypted: Vec<u8> = code.bytes().enumerate().map(|(i, b)| {
            b ^ key[i % key_len] ^ roll.wrapping_add((i & 0xFF) as u8)
        }).collect();

        let b64 = b64_encode(&encrypted);
        let chunk_n = self.rng.gen_range(20..40usize);
        let csz     = (b64.len() / chunk_n).max(4);
        let b64_expr: String = b64.as_bytes().chunks(csz)
            .map(|c| format!("\"{}\"", std::str::from_utf8(c).unwrap_or("")))
            .collect::<Vec<_>>()
            .join("..");

        let key_nums: String = key.iter().map(|b| b.to_string()).collect::<Vec<_>>().join(",");

        let va=self.gen_name(); let vl=self.gen_name(); let vi=self.gen_name();
        let vb=self.gen_name(); let vv=self.gen_name(); let vf=self.gen_name();
        let vs=self.gen_name(); let vo=self.gen_name(); let vc1=self.gen_name();
        let vc2=self.gen_name(); let vln=self.gen_name(); let vpd=self.gen_name();
        let vg=self.gen_name(); let vr=self.gen_name(); let vk=self.gen_name();
        let vrl=self.gen_name(); let vkl=self.gen_name(); let vk1=self.gen_name();
        let vk2=self.gen_name(); let vd=self.gen_name(); let vfn=self.gen_name();
        let vky=self.gen_name(); let vok=self.gen_name();

        let alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        let alpha_bytes: Vec<String> = alpha.bytes().map(|b| b.to_string()).collect();
        let alpha_expr = alpha_bytes.join(",");

        let mut s = String::with_capacity(b64.len() + 2048);
        s += &format!("local {va}=string.char({alpha_expr})\n");
        s += &format!("local {vl}={{}}\n");
        s += &format!("for {vi}=1,64 do {vl}[string.byte({va},{vi})]={vi}-1 end\n");
        s += &format!("local function {vf}({vs})\n");
        s += &format!("local {vo},{vc1},{vc2},{vln}={{}},0,0,#{vs}\n");
        s += &format!("for {vi}=1,{vln} do\n");
        s += &format!("local {vb}=string.byte({vs},{vi})\n");
        s += &format!("local {vv}={vl}[{vb}]\n");
        s += &format!("if {vv} then\n");
        s += &format!("{vc1}=bit32.bor(bit32.lshift({vc1},6),{vv}) {vc2}={vc2}+1\n");
        s += &format!("if {vc2}==4 then\n");
        s += &format!("table.insert({vo},string.char(bit32.band(bit32.rshift({vc1},16),255)))\n");
        s += &format!("table.insert({vo},string.char(bit32.band(bit32.rshift({vc1},8),255)))\n");
        s += &format!("table.insert({vo},string.char(bit32.band({vc1},255)))\n");
        s += &format!("{vc1}=0 {vc2}=0 end end end\n");
        s += &format!("if {vc2}==3 then local {vpd}=bit32.rshift({vc1},2)\n");
        s += &format!("table.insert({vo},string.char(bit32.band(bit32.rshift({vpd},8),255)))\n");
        s += &format!("table.insert({vo},string.char(bit32.band({vpd},255)))\n");
        s += &format!("elseif {vc2}==2 then\n");
        s += &format!("table.insert({vo},string.char(bit32.band(bit32.rshift({vc1},4),255)))\n");
        s += &format!("end return table.concat({vo}) end\n");
        s += &format!("local function {vg}({vr},{vk},{vrl})\n");
        s += &format!("local {vo},{vln},{vkl}={{}},#{vr},#{vk}\n");
        s += &format!("for {vi}=1,{vln} do\n");
        s += &format!("local {vb}=string.byte({vr},{vi})\n");
        s += &format!("local {vk1}={vk}[(({vi}-1)%{vkl})+1]\n");
        s += &format!("local {vk2}=bit32.band({vrl}+(({vi}-1)%256),255)\n");
        s += &format!("{vo}[{vi}]=string.char(bit32.bxor({vb},{vk1},{vk2})) end\n");
        s += &format!("return table.concat({vo}) end\n");
        s += &format!("local {vky}={{{key_nums}}}\n");
        s += &format!("local {vrl}={roll}\n");
        s += &format!("local {vs}={b64_expr}\n");
        s += &format!("local {vd}={vg}({vf}({vs}),{vky},{vrl})\n");
        s += &format!("local {vfn}=(loadstring or load)({vd})\n");
        s += &format!("if type({vfn})~=\"function\" then return end\n");
        s += &format!("local {vok}=pcall({vfn})\n");
        s
    }

    // ─── Guards: exploit API detection ───────────────────────────────────────
    fn env_detect_lua(&mut self) -> String {
        let mut checks: Vec<String> = EXPLOIT_APIS.iter()
            .map(|api| format!("if _G[\"{api}\"]~=nil then repeat until false end"))
            .collect();
        checks.push("if type(bit32)~=\"table\" then repeat until false end".into());
        checks.push("if type(string.byte)~=\"function\" then repeat until false end".into());
        checks.push("if type(math.floor)~=\"function\" then repeat until false end".into());
        checks.push("if type(table.insert)~=\"function\" then repeat until false end".into());
        checks.push("if debug and type(debug)==\"table\" then if debug.setupvalue or debug.sethook then repeat until false end end".into());
        let iter = self.hide_const(150000);
        checks.push(format!(
            "do local _t=os.clock();local _s=0;for _i=1,{iter} do _s=_s+_i end;if os.clock()-_t>3 then repeat until false end end"
        ));
        self.shuffle_vec(&mut checks);
        checks.join("\n")
    }

    fn roblox_anti_cheat(&mut self) -> String {
        let a=self.gen_name(); let b=self.gen_name(); let c=self.gen_name();
        let d=self.gen_name(); let e=self.gen_name(); let f=self.gen_name();
        let mut checks = vec![
            format!("local {a}=pcall(function() assert(type(game)==\"userdata\") assert(game.ClassName==\"DataModel\") end)\nif not {a} then repeat until false end"),
            format!("local {b}=pcall(function() assert(type(workspace)==\"userdata\") assert(workspace.ClassName==\"Workspace\") end)\nif not {b} then repeat until false end"),
            format!("local {c}=pcall(function() local _=game:GetService(\"RunService\");assert(type(_)==\"userdata\") end)\nif not {c} then repeat until false end"),
            format!("local {d}=pcall(function() if script then assert(type(script)==\"userdata\") end end)"),
            format!("local {e}=pcall(function() local _=getrawmetatable and getrawmetatable(game) or nil;if _ ~=nil then repeat until false end end)"),
            format!("local {f}=pcall(function() local _=game:GetService(\"Players\");assert(type(_)==\"userdata\") end)\nif not {f} then repeat until false end"),
        ];
        self.shuffle_vec(&mut checks);
        checks.join("\n")
    }

    fn anti_decompiler_lua(&mut self) -> String {
        let mut traps = Vec::new();
        let n1 = self.gen_name();
        let garbage: String = (0..16).map(|_| format!("\\{}", self.rng.gen_range(1u8..127))).collect();
        traps.push(format!("local {}=(function() return \"{}\" end)()", n1, garbage));

        let n2 = self.gen_name();
        let rot: u32 = self.rng.gen_range(1..31);
        let val: u32 = self.rng.gen_range(1..0x7FFFFFFF);
        let expected = val.rotate_left(rot).rotate_right(rot);
        traps.push(format!(
            "local {n}=bit32.rrotate(bit32.lrotate({val},{rot}),{rot}); if {n}~={exp} then repeat until false end",
            n=n2, val=val, rot=rot, exp=expected));

        let n3 = self.gen_name();
        let aa: u32 = self.rng.gen_range(1..0xFFFF);
        let bb: u32 = self.rng.gen_range(1..0xFFFF);
        traps.push(format!("local {n}=bit32.band({aa},{bb}); if {n}~={exp} then repeat until false end",
            n=n3, aa=aa, bb=bb, exp=aa&bb));

        let n4 = self.gen_name();
        traps.push(format!("local {n}=(table.unpack or unpack); if type({n})~=\"function\" then repeat until false end", n=n4));

        let n5 = self.gen_name();
        let k: usize = self.rng.gen_range(3..10);
        traps.push(format!("local {n}=string.rep(\"x\",{k}); if #{n}~={k} then repeat until false end", n=n5, k=k));

        let n6 = self.gen_name(); let n7 = self.gen_name();
        let magic: u32 = self.rng.gen_range(0x1000..0xFFFF);
        traps.push(format!("local {n6}={magic}\nlocal {n7}=function() return {n6} end\nif {n7}()~={magic} then repeat until false end"));

        let n8 = self.gen_name();
        let test_str = "NothingProtection";
        let test_len = test_str.len();
        let mut h: u32 = 0;
        for b in test_str.bytes() { h = h.wrapping_mul(31).wrapping_add(b as u32); }
        let h = h & 0x7FFFFFFF;
        traps.push(format!(
            "local {n8}=0; for _i=1,{test_len} do {n8}=bit32.band({n8}*31+string.byte(\"{test_str}\",_i),2147483647) end; if {n8}~={h} then repeat until false end"));

        let n9 = self.gen_name();
        let tlen: usize = self.rng.gen_range(3..10);
        traps.push(format!(
            "local {n9}={{}} for _i=1,{tlen} do {n9}[_i]=_i end; if #{n9}~={tlen} then repeat until false end"));

        self.shuffle_vec(&mut traps);
        traps.join("\n")
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────
    pub fn hide_const(&mut self, n: i64) -> String {
        match self.rng.gen_range(0..6usize) {
            0 => { let k = self.rng.gen_range(100..9999i64); format!("({} - {})", n + k, k) }
            1 => { let k = self.rng.gen_range(2..50i64);     format!("({} / {})", n * k, k) }
            2 => { let a = self.rng.gen_range(1..500i64);    format!("({} + {} - {})", n, a, a) }
            3 => { let k: u32 = self.rng.gen_range(1..31);   format!("bit32.lrotate(bit32.rrotate({},{k}),{k})", n, k=k) }
            4 => { let p = self.rng.gen_range(2..10usize);   format!("(string.len(\"{}\") + {})", "x".repeat(p), n - p as i64) }
            _ => n.to_string(),
        }
    }

    pub fn gen_name(&mut self) -> String {
        let chars = "Il1l0O_";
        let len   = self.rng.gen_range(10..17usize);
        let mut name = String::from("_");
        for _ in 0..len {
            name.push(chars.chars().nth(self.rng.gen_range(0..chars.len())).unwrap());
        }
        name
    }

    fn shuffle_vec(&mut self, v: &mut Vec<String>) {
        for i in (1..v.len()).rev() { let j = self.rng.gen_range(0..=i); v.swap(i, j); }
    }
}

pub fn b64_encode(data: &[u8]) -> String {
    const T: &[u8;64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity((data.len() * 4 / 3) + 4);
    for chunk in data.chunks(3) {
        let b0 = chunk[0];
        let b1 = *chunk.get(1).unwrap_or(&0);
        let b2 = *chunk.get(2).unwrap_or(&0);
        let n  = ((b0 as u32) << 16) | ((b1 as u32) << 8) | (b2 as u32);
        out.push(T[((n >> 18) & 63) as usize] as char);
        out.push(T[((n >> 12) & 63) as usize] as char);
        out.push(if chunk.len() > 1 { T[((n >> 6) & 63) as usize] as char } else { '=' });
        out.push(if chunk.len() > 2 { T[(n & 63)  as usize] as char }        else { '=' });
    }
    out
}
