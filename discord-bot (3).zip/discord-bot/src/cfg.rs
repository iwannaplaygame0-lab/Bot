use rand::Rng;

pub struct CFGObfuscator {
    rng: rand::rngs::StdRng,
}

impl CFGObfuscator {
    pub fn new(seed: u64) -> Self {
        use rand::SeedableRng;
        Self { rng: rand::rngs::StdRng::seed_from_u64(seed) }
    }

    // Format a number as a random Luau literal: hex / binary-with-underscores / decimal
    fn numlit(&mut self, n: u64) -> String {
        match self.rng.gen_range(0u8..8) {
            0 => format!("0x{:X}", n),
            1 => format!("0X{:x}", n),
            2 => {
                let v = (n & 0xFFFF) as u32;
                if v == 0 { return "0".to_string(); }
                let bits = format!("{:b}", v);
                if bits.len() > 5 {
                    let mid = bits.len() - 4;
                    format!("0B{}__{}", &bits[..mid], &bits[mid..])
                } else { format!("0B{}", bits) }
            }
            3 => {
                let v = (n & 0xFFFF) as u32;
                if v == 0 { return "0".to_string(); }
                let bits = format!("{:b}", v);
                if bits.len() > 5 {
                    let mid = bits.len() - 4;
                    format!("0b{}_{}", &bits[..mid], &bits[mid..])
                } else { format!("0b{}", bits) }
            }
            4 => format!("0x{:04X}", n & 0xFFFF),
            5 => {
                let v = n & 0xFF;
                format!("0B{:04b}_{:04b}", (v >> 4) & 0xF, v & 0xF)
            }
            6 => {
                let v = n & 0xFF;
                format!("0B{:08b}", v)
            }
            _ => format!("{}", n),
        }
    }

    pub fn wrap_with_dispatch_noise(&mut self, code: &str) -> String {
        let state    = self.gen_name();
        let dispatch = self.gen_name();
        let sentinel = self.gen_name();
        let a: u32 = self.rng.gen_range(100..999);
        let b: u32 = self.rng.gen_range(100..999);
        let c: u32 = self.rng.gen_range(1000..9999);
        let af = self.numlit(a as u64);
        let bf = self.numlit(b as u64);
        let cf = self.numlit(c as u64);
        let dead1 = self.generate_dead_block();
        let dead2 = self.generate_dead_block();
        let dead3 = self.generate_dead_block();
        let opaque1 = self.opaque_true();
        let opaque2 = self.opaque_false();
        let opaque3 = self.opaque_true();
        let s0: u32 = self.rng.gen_range(10..50);
        let s1: u32 = self.rng.gen_range(51..100);
        let s2: u32 = self.rng.gen_range(101..150);
        let s0f = self.numlit(s0 as u64);
        let s1f = self.numlit(s1 as u64);
        let s2f = self.numlit(s2 as u64);
        let s0f2 = self.numlit(s0 as u64);
        let s1f2 = self.numlit(s1 as u64);
        let s2f2 = self.numlit(s2 as u64);
        let fff = self.numlit(0xFFFF);
        let fff2 = self.numlit(0xFFFF);

        format!(
r#"local {state} = {s0f}
local {sentinel} = (function()
  local _a = {af}; local _b = {bf}
  return bit32.band(bit32.bxor(_a, _b), {fff}) == bit32.band(bit32.bxor({af}, {bf}), {fff2})
end)()
local {dispatch}
{dispatch} = function(_st)
  if _st == {s0f2} then
    if {opaque2} then
{dead1}
    end
    return {dispatch}({s1f})
  elseif _st == {s1f2} then
    if not {sentinel} then
{dead2}
    end
    if {opaque1} then
      if bit32.band({cf}, {cf}) == {cf} then
        return {dispatch}({s2f})
      end
    end
    return {dispatch}({s2f2})
  elseif _st == {s2f2} then
    if {opaque3} then
      if not {opaque2} then
{dead3}
      end
{code}
    end
  end
end
{dispatch}({s0f2})
"#,
            state=state, sentinel=sentinel, dispatch=dispatch,
            af=af, bf=bf, cf=cf, fff=fff, fff2=fff2,
            s0f=s0f, s1f=s1f, s2f=s2f, s0f2=s0f2, s1f2=s1f2, s2f2=s2f2,
            opaque1=opaque1, opaque2=opaque2, opaque3=opaque3,
            dead1=dead1, dead2=dead2, dead3=dead3, code=code,
        )
    }

    pub fn wrap_goto_dispatch(&mut self, code: &str) -> String {
        let lbl_init   = format!("_lbl_{:08x}", self.rng.gen::<u32>());
        let lbl_noise1 = format!("_lbl_{:08x}", self.rng.gen::<u32>());
        let lbl_noise2 = format!("_lbl_{:08x}", self.rng.gen::<u32>());
        let lbl_main   = format!("_lbl_{:08x}", self.rng.gen::<u32>());
        let lbl_end    = format!("_lbl_{:08x}", self.rng.gen::<u32>());
        let cond1 = self.opaque_true();
        let cond2 = self.opaque_false();
        let dead1 = self.generate_dead_block();
        let dead2 = self.generate_dead_block();
        let v_state = self.gen_name();
        let a: u32 = self.rng.gen_range(10..999);
        let b: u32 = self.rng.gen_range(10..999);
        let af = self.numlit(a as u64);
        let bf = self.numlit(b as u64);
        let ffff = self.numlit(0xFFFF);
        let ffff2 = self.numlit(0xFFFF);
        let ab_xor = a ^ b;
        let ab_xor_f = self.numlit(ab_xor as u64);

        format!(
r#"do
  local {v_state} = bit32.bxor({af}, {bf})
  ::{lbl_init}::
  if {cond2} then
{dead1}
    goto {lbl_end}
  end
  goto {lbl_noise1}
  ::{lbl_noise1}::
  if bit32.band({v_state}, {ffff}) ~= bit32.band({ab_xor_f},{ffff2}) then
{dead2}
    goto {lbl_end}
  end
  goto {lbl_noise2}
  ::{lbl_noise2}::
  if not {cond1} then
    goto {lbl_end}
  end
  goto {lbl_main}
  ::{lbl_main}::
  do
{code}
  end
  ::{lbl_end}::
end
"#,
            v_state=v_state, lbl_init=lbl_init, lbl_noise1=lbl_noise1,
            lbl_noise2=lbl_noise2, lbl_main=lbl_main, lbl_end=lbl_end,
            cond1=cond1, cond2=cond2, dead1=dead1, dead2=dead2,
            af=af, bf=bf, ffff=ffff, ffff2=ffff2, ab_xor_f=ab_xor_f, code=code,
        )
    }

    pub fn wrap_multi_state(&mut self, code: &str, extra_states: usize) -> String {
        let sw = self.gen_name();
        let pc = self.gen_name();
        let n_states = 3 + extra_states;
        let entry: u32 = self.rng.gen_range(1..100);
        let final_state = entry + n_states as u32;
        let state_map: Vec<u32> = (0..n_states).map(|i| entry + i as u32).collect();
        let main_state = state_map[n_states / 2];

        let entryf       = self.numlit(entry as u64);
        let final_statef = self.numlit(final_state as u64);
        let main_statef  = self.numlit(main_state as u64);

        let mut junk_cases = String::new();
        for &s in &state_map {
            if s == main_state { continue; }
            let next = if s < main_state { main_state } else { final_state };
            let dead = self.generate_dead_block();
            let sf = self.numlit(s as u64);
            let nextf = self.numlit(next as u64);
            junk_cases.push_str(&format!(
                "  elseif {pc} == {sf} then\n    do\n{dead}\n    end\n    {pc} = {nextf}\n",
            ));
        }

        format!(
r#"local {pc} = {entryf}
local {sw}
{sw} = function()
  while {pc} ~= {final_statef} do
    if {pc} == {main_statef} then
      {pc} = {final_statef}
{code}
{junk}
    else
      {pc} = {final_statef}
    end
  end
end
{sw}()
"#,
            pc=pc, sw=sw, entryf=entryf, final_statef=final_statef, main_statef=main_statef,
            code=code, junk=junk_cases,
        )
    }

    fn opaque_true(&mut self) -> String {
        let n: u32 = self.rng.gen_range(2..255);
        let nf  = self.numlit(n as u64);
        let nf2 = self.numlit(n as u64);
        match self.rng.gen_range(0..6u8) {
            0 => format!("(bit32.band({nf},{nf2})=={nf})"),
            1 => format!("(bit32.bor(0,{nf})=={nf2})"),
            2 => {
                let m: u32 = self.rng.gen_range(1..100);
                let mf = self.numlit(m as u64);
                format!("(({nf}+{mf}-{mf})=={nf2})")
            }
            3 => format!("(type(tostring)==\"function\")"),
            4 => {
                let k: u32 = self.rng.gen_range(1..31);
                let kf = self.numlit(k as u64);
                format!("(bit32.lrotate(bit32.rrotate({nf},{kf}),{kf})=={nf2})")
            }
            _ => format!("(bit32.bxor({nf},0)=={nf2})"),
        }
    }

    fn opaque_false(&mut self) -> String {
        let n: u32 = self.rng.gen_range(1..255);
        let nf  = self.numlit(n as u64);
        let nf2 = self.numlit(n as u64);
        match self.rng.gen_range(0..5u8) {
            0 => format!("(bit32.bxor({nf},{nf2})~=0)"),
            1 => format!("(bit32.band({nf},0)~=0)"),
            2 => format!("({nf}~={nf2}+1)"),
            3 => format!("(type(nil)==\"number\")"),
            _ => format!("({nf}+1=={nf2})"),
        }
    }

    fn generate_dead_block(&mut self) -> String {
        let v1 = self.gen_name();
        let v2 = self.gen_name();
        let a: u32 = self.rng.gen_range(1..200);
        let b: u32 = self.rng.gen_range(1..50);
        let af = self.numlit(a as u64);
        let bf = self.numlit(b as u64);
        match self.rng.gen_range(0..7u8) {
            0 => format!(
                "      local {v1}={af}\n      for _i=1,{bf} do {v1}=bit32.bxor({v1},_i) end\n      {v1}=nil"),
            1 => format!(
                "      local {v1}=\"{hex}\"\n      local {v2}=string.len({v1})\n      {v2}=nil",
                hex=self.random_hex_str(8)),
            2 => format!(
                "      local {v1}={{}}\n      for _i=1,{bf} do {v1}[_i]=_i*{af} end\n      {v1}=nil"),
            3 => format!(
                "      local {v1}=0\n      local {v2}=function() return {af} end\n      {v1}={v2}()*0\n      {v1}=nil;{v2}=nil"),
            4 => format!(
                "      local {v1}=string.rep(\"x\",{bf})\n      {v1}=string.gsub({v1},\"x\",\"\")\n      {v1}=nil"),
            5 => format!(
                "      local {v1}=bit32.bxor({af},{bf})\n      {v1}=bit32.band({v1},{})\n      {v1}=nil",
                self.numlit(0xFFFFFFFF)),
            _ => {
                let c = self.rng.gen_range(2..30u32);
                let cf = self.numlit(c as u64);
                format!("      local {v1}={af}\n      {v1}=math.floor({v1}/{cf})*{cf}\n      {v1}=nil")
            }
        }
    }

    fn random_hex_str(&mut self, len: usize) -> String {
        (0..len).map(|_| format!("{:x}", self.rng.gen::<u8>())).collect::<String>()
    }

    fn gen_name(&mut self) -> String {
        let chars: Vec<char> = "Il1l0OQq_oO".chars().collect();
        let mut name = String::from("_");
        for _ in 0..11 {
            name.push(chars[self.rng.gen_range(0..chars.len())]);
        }
        name
    }
}
